//
//  webViewViewController.h
//  PassGuardCtrlDemo_src
//
//  Created by microdone on 14/12/4.
//  Copyright (c) 2014年 microdone. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "PassGuardViewController.h"
@interface webViewViewController : UIViewController<instertWebviewTextDelegate,UIWebViewDelegate,BarDelegate>
@property (retain, nonatomic) IBOutlet UIWebView *webView;

@end
