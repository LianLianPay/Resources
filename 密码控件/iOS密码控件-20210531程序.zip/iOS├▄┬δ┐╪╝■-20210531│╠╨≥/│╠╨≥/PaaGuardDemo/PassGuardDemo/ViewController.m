//
//  ViewController.m
//  PassGuardDemo
//
//  Created by microdone on 2016/10/21.
//  Copyright © 2016年 microdone. All rights reserved.
//

#import "ViewController.h"
#import "CodeViewController.h"
#import "PassGuardCtrl.h"

@interface ViewController ()

@property (strong, nonatomic) IBOutlet UILabel *pgVersionLab;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    //[PassGuardTextField initPassGuardCtrl];
    _pgVersionLab.text = [NSString stringWithFormat:@"当前PassGuard版本:%@",[PassGuardTextField getVersion]];
}

- (void)viewWillAppear:(BOOL)animated {
    [self.navigationController setNavigationBarHidden:YES animated:animated];
    [super viewWillAppear:animated];
}

- (void)viewWillDisappear:(BOOL)animated {
    [self.navigationController setNavigationBarHidden:NO animated:animated];
    [super viewWillDisappear:animated];
}

- (IBAction)toCodeVC:(id)sender {
    CodeViewController *codeVC = [[CodeViewController alloc] init];
    [self.navigationController pushViewController:codeVC animated:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
