function sendCommand(cmd){
    var url="testapp:"+cmd;
    document.location = url;
}

function clickLink(){
    sendCommand("showkeyboard");
}

function getoutputaes (){
    sendCommand("aes");
}

