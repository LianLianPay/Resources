//
//  ViewController.m
//  PassGuardCtrlDemo_src
//
//  Created by microdone on 16/4/22.
//  Copyright © 2016年 microdone. All rights reserved.
//

#import "CodeViewController.h"
#import "Masonry.h"
#import "PassGuardCtrl.h"

@interface CodeViewController ()<DoneDelegate,UITextFieldDelegate,instertWebviewTextDelegate>
{
    UIScrollView *scrollView;
    UIView *container;
    
    PassGuardTextField *m_mytextfield1;
    PassGuardTextField *m_mytextfield2;
    
    UILabel *inputR1Label;
    UITextField *inputR1;
    UILabel *inputR2Label;
    UITextField *inputR2;
    UIButton *btnIsMatchR2;
    UISegmentedControl *pgBtnAnimationControl;
    
    UISwitch *jtSwitchMode;
    UISwitch *jtSwitchM_hasstatus;
    UISwitch *jtSwitchLX;//按键乱序
    UISwitch *jtSwitchnumber;//数字键盘
    UISwitch *jtSwitchdotDelay;//延迟显示
    UILabel *modeLabel;
    UILabel *hasstatusLabel;
    UILabel *LXLabel;
    UILabel *NuberLabel;
    UILabel *dotDelay;//延迟显示
    
    UITextView *textview;
}
@end

@implementation CodeViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self addView];
    
    [self makeConstraints];
    
    
}
-(void)viewWillAppear:(BOOL)animated{
 
    
}

- (void) bf:(NSString *)paramString{
    NSLog(@"%@", paramString);
    [m_mytextfield1 becomeFirstResponder];
    
    [self performSelector:@selector(closeKeyboard:) withObject:@"closeKeyboard" afterDelay:1.0];
}

- (void) closeKeyboard:(NSString *)paramString{
    NSLog(@"%@", paramString);
    [m_mytextfield1 resignFirstResponder];
    
    [self performSelector:@selector(bf:) withObject:@"Grand Central Dispatch" afterDelay:1.0];
}

- (void)addView{
    self.view.backgroundColor = [UIColor lightGrayColor];
    // [self.view setTranslatesAutoresizingMaskIntoConstraints:NO];
    scrollView = [UIScrollView new];
    scrollView.backgroundColor = [UIColor lightGrayColor];
    UITapGestureRecognizer *tabHideKeyBoard=[[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(hideKeyBoard)];
    [scrollView addGestureRecognizer: tabHideKeyBoard];
    [self.view addSubview:scrollView];
    
    container = [UIView new];
    // container.backgroundColor = [UIColor redColor];
    [scrollView addSubview:container];
    
    m_mytextfield1 = [[PassGuardTextField alloc] init];
   // m_mytextfield1.keyboardType = UIKeyboardTypeNumberPad;
    m_mytextfield1.placeholder = nil;
    m_mytextfield1.borderStyle = UITextBorderStyleRoundedRect;
    [m_mytextfield1 set_DoneDelegate:self];
    [m_mytextfield1 setWebdelegate:self];
    [m_mytextfield1 setDelegate:self];
   
    m_mytextfield1.clearButtonMode = UITextFieldViewModeWhileEditing;
    [m_mytextfield1 setM_iMaxLen:32];
    // [m_mytextfield1 setDelegate:self];
    [m_mytextfield1 setM_license:PassLicenseStr];
    //测试平台公钥
    [m_mytextfield1 setM_strInput2:[[NSString alloc] initWithFormat:@"%s", "MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCSS/DiwdCf/aZsxxcacDnooGph3d2JOj5GXWi+q3gznZauZjkNP8SKl3J2liP0O6rU/Y/29+IUe+GTMhMOFJuZm1htAtKiu5ekW0GlBMWxf4FPkYlQkPE0FtaoMP3gYfh+OwI+fIRrpW3ySn3mScnc6Z700nU/VYrRkfcSCbSnRwIDAQAB"]];
    
   // [m_mytextfield1 setM_strInput2:[[NSString alloc] initWithFormat:@"%s", "3081890281810092d9d8d04fb5f8ef9b8374f21690fd46fdbf49b40eeccdf416b4e2ac2044b0cfe3bd67eb4416b26fd18c9d3833770a526fd1ab66a83ed969af74238d6c900403fc498154ec74eaf420e7338675cad7f19332b4a56be4ff946b662a3c2d217efbe4dc646fb742b8c62bfe8e25fd5dc59e7540695fa8b9cd5bfd9f92dfad009d230203010001"]];
    
    
    // [m_mytextfield1 setM_strInput2:[[NSString alloc] initWithFormat:@"%s", "MIIBCgKCAQEAvKg1r8u0Vh+y5ashicuNoPNgBeUTmO1y6GWBsgC3qzqtew3NqGPsNy3e3mWDp8XssMxD9TgPkD9vm6qWDSLi8wPmLlxXyAM0i3XyKPEN8IRjwOEsyR6HqcQvv9/c56qRTZ33idrDwuPokafkXusidw64QfK5JlF+hQRykFH3F2vSt9L5P7Ml2Vrrp9OHVFnLvdU9toVb6bK9LR0HTKYI7VwPJhw+F/flAtsJiQ2LzESnhopr7kob71fqdPtpXkCdRIQmNb+zjZ+47nupKqWjqKLhNLvNicMXSH9TwUcCxeUPgjhAkwRdcQaaRCL0s6kKvHIxQ38Kg4Os/8vB+s9dMQIDAQAB"]];
//    [m_mytextfield1 setM_strInput2:[[NSString alloc] initWithFormat:@"%s", "MIIDsDCCAxmgAwIBAgIQeJ0/mrqG2CVi8D61fznnkzANBgkqhkiG9w0BAQUFADAkMQswCQYDVQQGEwJDTjEVMBMGA1UEChMMQ0ZDQSBURVNUIENBMB4XDTExMDYwMjA4MTU0M1oXDTExMDcwMjA4MTU0M1owdjELMAkGA1UEBhMCQ04xFTATBgNVBAoTDENGQ0EgVEVTVCBDQTEOMAwGA1UECxMFREdSQ0MxFDASBgNVBAsTC0VudGVycHJpc2VzMSowKAYDVQQDFCEwNDFAM1dUUHdkVGVzdEBXVFB3ZFRlc3RAMDAwMDAwMDEwgZ8wDQYJKoZIhvcNAQEBBQADgY0AMIGJAoGBAJLZ2NBPtfjvm4N08haQ/Ub9v0m0DuzN9Ba04qwgRLDP471n60QWsm/RjJ04M3cKUm/Rq2aoPtlpr3QjjWyQBAP8SYFU7HTq9CDnM4Z1ytfxkzK0pWvk/5RrZio8LSF+++TcZG+3QrjGK/6OJf1dxZ51QGlfqLnNW/2fkt+tAJ0jAgMBAAGjggGPMIIBizAfBgNVHSMEGDAWgBRGctwlcp8CTlWDtYD5 C9vpk7P0RTAdBgNVHQ4EFgQUBqh+5IwL3tg/OSysLyQnEFVtKBowCwYDVR0PBAQDAgTwMAwGA1UdEwQFMAMBAQAwOwYDVR0lBDQwMgYIKwYBBQUHAwEGCCsGAQUFBwMCBggrBgEFBQcDAwYIKwYBBQUHAwQGCCsGAQUFBwMIMIHwBgNVHR8EgegwgeUwT6BNoEukSTBHMQswCQYDVQQGEwJDTjEVMBMGA1UEChMMQ0ZDQSBURVNUIENBMQwwCgYDVQQLEwNDUkwxEzARBgNVBAMTCmNybDEyN18xMzUwgZGggY6ggYuGgYhsZGFwOi8vdGVzdGxkYXAuY2ZjYS5jb20uY246Mzg5L0NOPWNybDEyN18xMzUsT1U9Q1JMLE89 Q0ZDQSBURVNUIENBLEM9Q04/Y2VydGlmaWNhdGVSZXZvY2F0aW9uTGlzdD9iYXNlP29iamVjdGNsYXNzPWNSTERpc3RyaWJ1dGlvblBvaW50MA0GCSqGSIb3DQEBBQUAA4GBAMbp6tCu4xIiyVaBfTeWzRKX32rt8awuj+CozwkM9lvwLppclM1YnT3Jc2gL7wZPzme8LXGu0NMsqAQ6RQNyNKj4O2nD8eeCmZ3AtRRUyd4boG6x5SE5oRX8Ms2m/8EPxSVbSndg6hGr3lMPv5cqURM5YlSPLhzZdyVMdf06npBm"]];
    
    [m_mytextfield1 setM_strInputR1:@"\\w*"]; //输入过程中字符限制 提示（正则表达式） @"[\\d\\.]"
    [m_mytextfield1 setM_strInputR2:@"\\d*"];//设置正则表达式isMatch()函数使用
    
    [m_mytextfield1 setM_strInput3:[[NSString alloc] initWithFormat:@"%s", "!@^&*JI"]]; //设置随机字符串
    
    [m_mytextfield1 setM_strInput1:[[NSString alloc] initWithFormat:@"%s", "abcdefghijklmnopqrstuvwxyz123456"]];
    [m_mytextfield1 setM_strInputX:@"2DBCE86F32AA6465565223FB6880FD4A9904CF5DF922E523EEF08837DE16FBEA"];
    [m_mytextfield1 setM_strInputY:@"BDDCC33FE334D7CFE4158EA5B1F7FAF1D26317BED4FC18EE2EF4339A7FCFC5DC"];
    [container addSubview:m_mytextfield1];
    
    //NSArray *btnArr = @[btnAES,btnRSA,btnMD5,btnLen,btnSM2,btnSM3,btnSM4,btnPower,btnClean];
    NSArray *titleArr = @[@"AES",@"RSA",@"MD5",@"length",@"SM2+SM4",@"SM3",@"SM4",@"Power",@"Clean"];
    NSArray *selArr = @[NSStringFromSelector(@selector(aes:)),NSStringFromSelector(@selector(rsa:)),NSStringFromSelector(@selector(md5:)),NSStringFromSelector(@selector(pwdlength:)),NSStringFromSelector(@selector(sm2:)),NSStringFromSelector(@selector(sm3:)),NSStringFromSelector(@selector(sm4:)),NSStringFromSelector(@selector(pwdpower:)),NSStringFromSelector(@selector(pwdclean:))];
    
    for (int i = 0;i<titleArr.count;i++) {
        SEL tempSel = NSSelectorFromString(selArr[i]);
        UIButton *tempBtn = [UIButton buttonWithType:UIButtonTypeRoundedRect];
        tempBtn.tag= 1000+i;
        [tempBtn setBackgroundColor:[UIColor whiteColor]];
        [tempBtn setTitle:titleArr[i] forState:UIControlStateNormal];
        [tempBtn setTitle:titleArr[i] forState:UIControlStateHighlighted];
        [tempBtn addTarget:self action:tempSel forControlEvents:UIControlEventTouchUpInside];
        [container addSubview:tempBtn];
    }
    
    inputR1Label = [UILabel new];
    inputR1Label.text = @"inputR1";
    inputR1 =[UITextField new];
    inputR1.tag = 1;
    inputR1.delegate = self;
    inputR1.borderStyle = UITextBorderStyleRoundedRect;
    inputR1.keyboardType = UIKeyboardTypeASCIICapable;
    [inputR1 setAutocapitalizationType:UITextAutocapitalizationTypeNone];
    [inputR1 setAutocorrectionType:UITextAutocorrectionTypeNo];
    inputR1.text = @"\\w*";
    
    
    [container addSubview:inputR1Label];
    [container addSubview:inputR1];
    
    inputR2Label = [UILabel new];
    inputR2Label.text = @"inputR2";
    inputR2 =[UITextField new];
    inputR2.tag = 2;
    inputR2.delegate = self;
    inputR2.borderStyle = UITextBorderStyleRoundedRect;
    inputR2.keyboardType = UIKeyboardTypeNumberPad;
    [inputR2 setAutocorrectionType:UITextAutocorrectionTypeNo];[inputR1 setAutocapitalizationType:UITextAutocapitalizationTypeNone];
    [inputR2 setAutocapitalizationType:UITextAutocapitalizationTypeNone];
    inputR2.text = @"\\d*";
    [container addSubview:inputR2Label];
    [container addSubview:inputR2];
    btnIsMatchR2 = [UIButton buttonWithType:UIButtonTypeSystem];
    [btnIsMatchR2 setBackgroundColor:[UIColor whiteColor]];
    [btnIsMatchR2 setTitle:@"IsMatchR2" forState:UIControlStateNormal];
    [btnIsMatchR2 setTitle:@"IsMatchR2" forState:UIControlStateHighlighted];
    [btnIsMatchR2 addTarget:self action:@selector(isMatchR2:) forControlEvents:UIControlEventTouchUpInside];
    btnIsMatchR2.titleLabel.font = [UIFont systemFontOfSize: 11.0];
    [container addSubview:btnIsMatchR2];
    
    //
    pgBtnAnimationControl = [[UISegmentedControl alloc] init];
    //修改字体的默认颜色与选中颜色
    //选择后的字体颜色（在NSDictionary中 可以添加背景颜色和字体的背景颜色）
    NSDictionary *dic = [NSDictionary dictionaryWithObjectsAndKeys:[UIColor whiteColor],
                         NSForegroundColorAttributeName,
                         [UIFont systemFontOfSize:13],
                         NSFontAttributeName,nil];
    
    [pgBtnAnimationControl setTitleTextAttributes:dic forState:UIControlStateSelected];
    
    //默认字体颜色
    NSDictionary *dic1 = [NSDictionary dictionaryWithObjectsAndKeys:[UIColor blackColor],
                          NSForegroundColorAttributeName,
                          [UIFont systemFontOfSize:13],
                          NSFontAttributeName,nil];
    
    [pgBtnAnimationControl setTitleTextAttributes:dic1 forState:UIControlStateNormal];
    
    [pgBtnAnimationControl insertSegmentWithTitle:@"无按键动画" atIndex:0 animated:YES];
    [pgBtnAnimationControl insertSegmentWithTitle:@"按键放大" atIndex:1 animated:YES];
    [pgBtnAnimationControl insertSegmentWithTitle:@"模拟原生效果" atIndex:2 animated:YES];
    pgBtnAnimationControl.selectedSegmentIndex = 0;
    
     [pgBtnAnimationControl addTarget:self action:@selector(segmentValueChanged:) forControlEvents:UIControlEventValueChanged];
    [container addSubview:pgBtnAnimationControl];
    ////////////////
    jtSwitchMode = [UISwitch new];
    [jtSwitchMode setOn:YES];
    [jtSwitchMode addTarget:self action:@selector(modeStateChanged) forControlEvents:UIControlEventTouchUpInside];
    ////////////////
    jtSwitchM_hasstatus = [UISwitch new];
    [jtSwitchM_hasstatus setOn:YES];
    [jtSwitchM_hasstatus addTarget:self action:@selector(hasstatusStateChanged) forControlEvents:UIControlEventTouchUpInside];
    ////////////////
    jtSwitchLX = [UISwitch new];
    [jtSwitchLX addTarget:self action:@selector(lxStateChanged) forControlEvents:UIControlEventTouchUpInside];
    ////////////////
    
    jtSwitchnumber = [UISwitch new];
    [jtSwitchnumber addTarget:self action:@selector(NumberStateChanged) forControlEvents:UIControlEventTouchUpInside];
    jtSwitchdotDelay = [UISwitch new];
    [jtSwitchdotDelay addTarget:self action:@selector(delayStateChanged) forControlEvents:UIControlEventTouchUpInside];
    
    modeLabel = [UILabel new];
    modeLabel.text = @"密文模式";
    modeLabel.adjustsFontSizeToFitWidth = YES;
    hasstatusLabel = [UILabel new];
    hasstatusLabel.text = @"按键状态";
    hasstatusLabel.adjustsFontSizeToFitWidth = YES;
    LXLabel = [UILabel new];
    LXLabel.text = @"切换乱序";
    LXLabel.adjustsFontSizeToFitWidth = YES;
    NuberLabel = [UILabel new];
    NuberLabel.text = @"数字键盘";
    NuberLabel.adjustsFontSizeToFitWidth = YES;
    dotDelay = [UILabel new];
    dotDelay.text= @"延迟显示";
    dotDelay.adjustsFontSizeToFitWidth = YES;
    textview = [UITextView new]; //初始化大小
    textview.textColor = [UIColor blackColor];//设置textview里面的字体颜色
    textview.editable =false;
    textview.font = [UIFont fontWithName:@"Arial" size:14.0];//设置字体名字和字体大小
    textview.backgroundColor = [UIColor whiteColor];//设置它的背景颜色
}

- (void)makeConstraints{
    int padding = 20;
    int left3rightPadding = 40;
    
    [scrollView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.equalTo(self.view).with.insets(UIEdgeInsetsMake(20,5,5,5));
    }];
    
    [container mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.equalTo(scrollView);
        make.width.equalTo(scrollView);
    }];
    
    [m_mytextfield1 mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(container.mas_top).with.offset(30);
        make.left.equalTo(container.mas_left).with.offset(20);
        make.right.equalTo(container.mas_right).with.offset(-20);
        make.height.mas_equalTo(@(35));
    }];
    
    NSArray *btnLine1Views = @[[container viewWithTag:1000],[container viewWithTag:1001],[container viewWithTag:1002]];
    UIView *btnLine1containerView = [UIView new];
    [container addSubview:btnLine1containerView];
    [btnLine1containerView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(m_mytextfield1.mas_bottom).with.offset(padding);
        make.left.equalTo(container.mas_left).with.offset(left3rightPadding);
        make.right.equalTo(container.mas_right).with.offset(-left3rightPadding);
        make.height.mas_equalTo(@(40));
    }];
    [self makeEqualWidthViews:btnLine1Views inView:btnLine1containerView LRpadding:0 viewPadding:10];
    
    NSArray *btnLine2Views = @[[container viewWithTag:1003],[container viewWithTag:1004],[container viewWithTag:1005]];
    UIView *btnLine2containerView = [UIView new];
    [container addSubview:btnLine2containerView];
    [btnLine2containerView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo([container viewWithTag:1002].mas_bottom).with.offset(padding);
        make.left.equalTo(container.mas_left).with.offset(left3rightPadding);
        make.right.equalTo(container.mas_right).with.offset(-left3rightPadding);
        make.height.mas_equalTo(@(40));
    }];
    [self makeEqualWidthViews:btnLine2Views inView:btnLine2containerView LRpadding:0 viewPadding:10];
    
    
    NSArray *btnLine3Views = @[[container viewWithTag:1006],[container viewWithTag:1007],[container viewWithTag:1008]];
    UIView *btnLine3containerView = [UIView new];
    [container addSubview:btnLine3containerView];
    [btnLine3containerView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(btnLine2containerView.mas_bottom).with.offset(padding);
        make.left.equalTo(container.mas_left).with.offset(left3rightPadding);
        make.right.equalTo(container.mas_right).with.offset(-left3rightPadding);
        make.height.mas_equalTo(@(40));
    }];
    [self makeEqualWidthViews:btnLine3Views inView:btnLine3containerView LRpadding:0 viewPadding:10];
    
    //正则
    
    [inputR1Label mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(btnLine3containerView.mas_bottom).with.offset(padding);
        make.left.equalTo(container.mas_left).with.offset(40);
        make.width.equalTo(container.mas_width).multipliedBy(0.2);
        make.height.mas_equalTo(@(35));
    }];
    [inputR1 mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(btnLine3containerView.mas_bottom).with.offset(padding);
        make.left.equalTo(inputR1Label.mas_right);
        make.right.equalTo(container.mas_right).with.offset(-40);
        make.height.mas_equalTo(@(35));
    }];
    
    [inputR2Label mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(inputR1Label.mas_bottom).with.offset(padding);
        make.left.equalTo(container.mas_left).with.offset(40);
        make.width.equalTo(container.mas_width).multipliedBy(0.2);
        make.height.mas_equalTo(@(35));
    }];
    [inputR2 mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(inputR1Label.mas_bottom).with.offset(padding);
        make.left.equalTo(inputR2Label.mas_right);
        make.width.equalTo(container.mas_width).multipliedBy(0.35);
        make.height.mas_equalTo(@(35));
    }];
    
    [btnIsMatchR2 mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(inputR1Label.mas_bottom).with.offset(padding);
        make.left.equalTo(inputR2.mas_right);
        make.right.equalTo(container.mas_right).with.offset(-40);
        //make.width.equalTo(container.mas_width).multipliedBy(0.6);
        make.height.mas_equalTo(@(35));
    }];
    
    
    [pgBtnAnimationControl mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(inputR2Label.mas_bottom).with.offset(padding);
         make.left.equalTo(container.mas_left).with.offset(padding);
        make.right.equalTo(container.mas_right).with.offset(-padding);
        //make.width.equalTo(container.mas_width).multipliedBy(0.6);
        make.height.mas_equalTo(@(35));
    }];
    
    NSArray *switchViews = (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPhone)?@[modeLabel,hasstatusLabel,LXLabel,NuberLabel,dotDelay]:@[modeLabel,hasstatusLabel,LXLabel,dotDelay];
    UIView *switchViewscontainerView = [UIView new];
    [container addSubview:switchViewscontainerView];
    [switchViewscontainerView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(pgBtnAnimationControl.mas_bottom).with.offset(0);
        make.left.equalTo(container.mas_left).with.offset(padding);
        make.right.equalTo(container.mas_right).with.offset(-padding);
        make.height.mas_equalTo(@(50));
    }];
    [self makeEqualWidthViews:switchViews inView:switchViewscontainerView LRpadding:0 viewPadding:10];
    
    NSArray *switchViews1 = (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPhone)? @[jtSwitchMode,jtSwitchM_hasstatus,jtSwitchLX,jtSwitchnumber,jtSwitchdotDelay]:@[jtSwitchMode,jtSwitchM_hasstatus,jtSwitchLX,jtSwitchdotDelay];
    UIView *switchViews1containerView = [UIView new];
    [container addSubview:switchViews1containerView];
    [switchViews1containerView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(switchViewscontainerView.mas_bottom);
        make.left.equalTo(container.mas_left).with.offset(padding);
        make.right.equalTo(container.mas_right).with.offset(-padding);
        make.height.mas_equalTo(@(50));
    }];
    [self makeEqualWidthViews:switchViews1 inView:switchViews1containerView LRpadding:0 viewPadding:10];
    
    [container addSubview:textview];
    [textview mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(switchViews1containerView.mas_bottom).offset(0);
        make.left.equalTo(container.mas_left).with.offset(left3rightPadding);
        make.right.equalTo(container.mas_right).with.offset(-left3rightPadding);
        make.height.mas_equalTo(@(100));
    }];

    [container mas_makeConstraints:^(MASConstraintMaker *make) {
        make.bottom.equalTo(textview.mas_bottom).with.offset(50);
    }];
}

/**
 *  将若干view等宽布局于容器containerView中
 *
 *  @param views         viewArray
 *  @param containerView 容器view
 *  @param LRpadding     距容器的左右边距
 *  @param viewPadding   各view的左右边距
 */
-(void)makeEqualWidthViews:(NSArray *)views inView:(UIView *)containerView LRpadding:(CGFloat)LRpadding viewPadding :(CGFloat)viewPadding
{
    UIView *lastView;
    for (UIView *view in views) {
        [containerView addSubview:view];
        if (lastView) {
            [view mas_makeConstraints:^(MASConstraintMaker *make) {
                make.top.bottom.equalTo(containerView);
                make.left.equalTo(lastView.mas_right).offset(viewPadding);
                make.width.equalTo(lastView);
            }];
        }else
        {
            [view mas_makeConstraints:^(MASConstraintMaker *make) {
                make.left.equalTo(containerView).offset(LRpadding);
                make.top.bottom.equalTo(containerView);
            }];
        }
        lastView=view;
    }
    [lastView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.equalTo(containerView).offset(-LRpadding);
    }];
}

- (IBAction)aes:(id)sender {
    
    NSString * stringText =[ m_mytextfield1 getOutput1];
    NSLog(@"%@", stringText);
    [m_mytextfield1 resignFirstResponder];
    textview.text = [NSString stringWithFormat:@"%@\nAES:%@\n",textview.text,stringText];
    
}

- (IBAction)rsa:(id)sender {
    NSString * stringText =[ m_mytextfield1 getOutput4:0];
    NSLog(@"%@",stringText);
    [m_mytextfield1 resignFirstResponder];
    textview.text = [NSString stringWithFormat:@"%@\nRSA:%@\n",textview.text,stringText];
}

- (IBAction)md5:(id)sender {
    NSString * stringText =[ m_mytextfield1 getOutput2];
    
    [m_mytextfield1 resignFirstResponder];
    textview.text = [NSString stringWithFormat:@"%@\nMD5:%@\n",textview.text,stringText];
}

- (IBAction)pwdlength:(id)sender {
    
    NSInteger ITERPassWDLength =[m_mytextfield1 getOutput3];
    NSString*stringText =[NSString stringWithFormat:@"%ld",(long)ITERPassWDLength];
    [m_mytextfield1 resignFirstResponder];
    textview.text = [NSString stringWithFormat:@"%@\nLength:%@\n",textview.text,stringText];
}
- (IBAction)pwdclean:(id)sender{
    [m_mytextfield1 Clean];
    textview.text = @"";
}

- (IBAction)pwdpower:(id)sender {
    NSArray *arr = [m_mytextfield1 getInputLevel];
    [m_mytextfield1 resignFirstResponder];
    textview.text = [NSString stringWithFormat:@"%@\npwdpower:%@\n",textview.text,arr.description];
}

- (IBAction)isMatchR2:(id)sender {
    BOOL ret  =[ m_mytextfield1 isMatch];
    
    [m_mytextfield1 resignFirstResponder];
    textview.text = [NSString stringWithFormat:@"%@\nisMatchR2:%@\n",textview.text,[NSString stringWithFormat:@"%d",ret]];
}

- (IBAction)sm2:(id)sender {
    NSString * stringText =[ m_mytextfield1 getOutput8];
    
    [m_mytextfield1 resignFirstResponder];
    textview.text = [NSString stringWithFormat:@"%@\nSM2+SM4:%@\n",textview.text,stringText];
}

- (IBAction)sm3:(id)sender {
    NSString * stringText =[ m_mytextfield1 getOutput6];
    
    [m_mytextfield1 resignFirstResponder];
    textview.text = [NSString stringWithFormat:@"%@\nSM3:%@\n",textview.text,stringText];
}

- (IBAction)sm4:(id)sender {
    NSString * stringText =[ m_mytextfield1 getOutput7];
    NSLog(@"stringText:%@",stringText);
    [m_mytextfield1 resignFirstResponder];
    textview.text = [NSString stringWithFormat:@"%@\nSM4:%@\n",textview.text,stringText];
}
- (void)hideKeyBoard{
    [m_mytextfield1 resignFirstResponder];
}

- (void)modeStateChanged
{
    if(jtSwitchMode.isOn == YES) {
        m_mytextfield1.m_mode = false;
    }
    else {
        m_mytextfield1.m_mode = true;
    }
}

- (void)hasstatusStateChanged
{
    if(jtSwitchM_hasstatus.isOn == YES) {
        m_mytextfield1.m_hasstatus = true;
    }
    else {
        m_mytextfield1.m_hasstatus = false;
    }
}

- (void)lxStateChanged
{
    if(jtSwitchLX.isOn)
    {
        [m_mytextfield1 setM_ikeyordertype:KEY_CHAOS_SWITCH_VIEW/*|KEY_CHAOS_PRESS_KEY*/|SHOW_ANIMATTION];
    }
    else
    {
        [m_mytextfield1 setM_ikeyordertype:KEY_NONE_CHAOS];
    }
}

- (void)segmentValueChanged:(UISegmentedControl*)sender
{
    
    if (sender.selectedSegmentIndex == 0) {
        
        [m_mytextfield1 setM_ikeypresstype:KEY_NONE_KEY_PRESS];
    }else if (sender.selectedSegmentIndex == 1){
        [m_mytextfield1 setM_ikeypresstype:KEY_IPAD_KEY_PRESS|KEY_IPHONE_KEY_PRESS];
        
    }else{
        [m_mytextfield1 setM_ikeypresstype:KEY_IPAD_KEY_PRESS|KEY_IPHONE_KEY_PRESS_NATIVE];
    }
}

- (void)delayStateChanged
{
    
    if (jtSwitchdotDelay.isOn) {
        m_mytextfield1.m_isDotDelay =false;
        
    }else{
        
        m_mytextfield1.m_isDotDelay =true;
    }
}

- (void)NumberStateChanged{
    
    [m_mytextfield1 resignFirstResponder];
    
    if (jtSwitchnumber.isOn) {
        m_mytextfield1.keyboardType = UIKeyboardTypeNumberPad;
    }else{
        m_mytextfield1.keyboardType = UIKeyboardTypeDefault;
    }
    [m_mytextfield1 becomeFirstResponder];
}

- (void)DoneFun:(id)sender{
    
    textview.text = [NSString stringWithFormat:@"%@\n键盘收起",textview.text];
}

-(void)instertWText{
    
    NSLog(@"长度:%ld",m_mytextfield1.text.length);
    //NSLog(@"MD5:%@",[m_mytextfield1 getOutput2]);
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField{
    if(textField.tag == 1){
        [m_mytextfield1 setM_strInputR1:textField.text]; //输入过程中字符限制 提示（正则表达式）
        
    }else if(textField.tag == 2){
        [m_mytextfield1 setM_strInputR2:textField.text];//设置正则表达式isMatch()函数使用
    }else{
        
    }
    
    [textField resignFirstResponder];
    
    
    return YES;
}


- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField;{
    return YES;
}

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string{
    return YES;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
