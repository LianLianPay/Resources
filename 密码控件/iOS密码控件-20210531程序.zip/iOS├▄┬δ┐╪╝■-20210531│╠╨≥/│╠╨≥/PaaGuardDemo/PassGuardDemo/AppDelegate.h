//
//  AppDelegate.h
//  PassGuardDemo
//
//  Created by microdone on 2016/10/21.
//  Copyright © 2016年 microdone. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

