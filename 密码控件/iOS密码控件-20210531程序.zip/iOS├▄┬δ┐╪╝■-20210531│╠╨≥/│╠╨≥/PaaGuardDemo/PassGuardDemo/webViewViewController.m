//
//  webViewViewController.m
//  PassGuardCtrlDemo_src
//
//  Created by microdone on 14/12/4.
//  Copyright (c) 2014年 microdone. All rights reserved.
//

#import "webViewViewController.h"

@interface webViewViewController ()
{
    PassGuardViewController *pgvc;
}

@end

@implementation webViewViewController
@synthesize webView;
- (void)viewDidLoad {
    [super viewDidLoad];
    
    NSString *filePath = [[NSBundle mainBundle] pathForResource:@"webview-passguard" ofType:@"js"];
    NSString *jsString = [[NSString alloc]initWithContentsOfFile:filePath encoding:NSUTF8StringEncoding error:nil];
    [self.webView stringByEvaluatingJavaScriptFromString:jsString];

    [webView setDelegate:self];
    
    NSMutableString* html5String = [[NSMutableString alloc] init];
    // 拼接一段HTML代码
    [html5String appendString:@"<html>"];
    [html5String appendString:@"<head>"];
    [html5String appendString:@"<title> 欢迎您 </title>"];
    [html5String appendString:@"</head>"];
    [html5String appendString:@"<body>"];//onclick='clickLink()'
    [html5String appendString:@"<br /><br /><br /><br /><br /> <div align=\"center\"><input onclick='clickLink()' readonly='readonly' style='width:220px;height:50px' type=\"password\" name=\"passwd\" placeholder='北京微通新成密码安全控件' id=\"passwd\" /></div><br /><br />"];
    [html5String appendString:@"<br /><br /> <div align=\"center\"><input style='width:150px;height:50px' type='button' name=\"aes\" id=\"aes\" value='获取AES' onclick='getoutputaes ()' /></div>"];
    [html5String appendString:@"</body>"];
    [html5String appendString:@"</html>"];

    [self.webView loadHTMLString:html5String
                         baseURL:[NSURL URLWithString:@"http://www.microdone.cn"]];
}

-(void)viewWillDisappear:(BOOL)animated{
    
    if(pgvc != nil){
        [pgvc dismiss];
    }
}

- (void)viewDidDisappear:(BOOL)animated{
    if(pgvc != nil){
        [pgvc dismiss];
    }
}

#pragma mark --
#pragma mark UIWebViewDelegate
- (BOOL)webView:(UIWebView *)webView shouldStartLoadWithRequest:(NSURLRequest *)request navigationType:(UIWebViewNavigationType)navigationType {
    
    NSString *requestString = [[request URL] absoluteString];
    NSArray *components = [requestString componentsSeparatedByString:@":"];
    if ([components count] > 1 && [(NSString *)[components objectAtIndex:0] isEqualToString:@"testapp"]) {
        if([(NSString *)[components objectAtIndex:1] isEqualToString:@"showkeyboard"])
        {
            if(nil == pgvc)
            {
                pgvc = [[PassGuardViewController alloc] init];
                [[pgvc m_tf] setWebdelegate:self];
                [pgvc setDelegate:self];
            }
            //setting attributes
            pgvc.m_bshowtoolbar =false;
            [[pgvc m_tf] setM_license:PassLicenseStr];
            //AES encypt key
            [pgvc m_tf].keyboardType = UIKeyboardTypeNumberPad;
            [pgvc m_tf].m_strInput2 =@"30818902818100D0C45F0FA7755B251BCA8B56673A6E99B5B1AA940026CE618B714FE125F07BE54167242911457BD12D8D44BD63EB25C17F5A4328F26E24975C0EC26E85164EAA57673DBDE440348582ABA64194990A085597FDDB41BB39671B619DAA3F5C5517CB682FF1132DE8D1F848E2107407B40FBA4158B15E2912AD1ED03926FDA950D90203010001";
            //            [[pgvc m_tf] setM_ikeyordertype:KEY_CHAOS_SWITCH_VIEW|KEY_CHAOS_PRESS_KEY];
            [pgvc m_tf].m_strInput1 =@"11111111111111111111111111111111";
            [pgvc show];
            
        }else if([(NSString *)[components objectAtIndex:1] isEqualToString:@"aes"]){
            NSString *aesStr = [[pgvc m_tf] getOutput1];
            
            [self.webView stringByEvaluatingJavaScriptFromString:[NSString stringWithFormat:@"alert('%@')",aesStr]];
            
        }
        
        return NO;
    }
    return YES;
}

- (void)webViewDidStartLoad:(UIWebView *)webView {
    NSLog(@"webViewDidStartLoad");
}

- (void)webViewDidFinishLoad:(UIWebView *)webView {
    NSLog(@"webViewDidFinishLoad");
}


-(void)instertWText{
    [self.webView stringByEvaluatingJavaScriptFromString:[NSString stringWithFormat:@"var field = document.getElementById('passwd');field.value= '%@';",[pgvc m_tf].text]];
}

-(void)HideFun:(id)sender
{
    NSLog(@"键盘收起了....");
    [self.webView stringByEvaluatingJavaScriptFromString:[NSString stringWithFormat:@"alert('键盘收起了')"]];
}

- (void)DoneFun:(id)sender{
    
   
}


@end
