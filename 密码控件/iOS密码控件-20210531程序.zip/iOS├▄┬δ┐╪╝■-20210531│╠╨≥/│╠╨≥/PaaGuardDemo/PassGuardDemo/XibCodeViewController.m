//
//  XibCodeViewController.m
//  PassGuardDemo
//
//  Created by microdone on 2016/10/21.
//  Copyright © 2016年 microdone. All rights reserved.
//

#import "XibCodeViewController.h"
#import "PassGuardCtrl.h"

@interface XibCodeViewController ()
@property (strong, nonatomic) IBOutlet PassGuardTextField *m_textfield1;

@end

@implementation XibCodeViewController
@synthesize m_textfield1;
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    [m_textfield1 setM_license:PassLicenseStr];
    //AES加密因子
     [m_textfield1 setM_strInput1:[[NSString alloc] initWithFormat:@"%s", "abcdefghijklmnopqrstuvwxyz123456"]];
    
}

- (void)viewWillAppear:(BOOL)animated {
    [self.navigationController setNavigationBarHidden:NO animated:animated];
    [super viewWillAppear:animated];
}

- (IBAction)aes:(id)sender {
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"AES" message:[m_textfield1 getOutput1] delegate:nil cancelButtonTitle:@"ok" otherButtonTitles:nil, nil];
    [alert show];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
