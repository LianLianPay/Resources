/**
 * Copyright © 2004-2018 LianlianPay.All Rights Reserved.
 */
package com.accp.demo.openaccount.domain;

import com.accp.demo.openaccount.domain.AbstractAPIReqDomain;
/**
 * 
* 描述说明
* 验证注册手机号请求类
* @version V1.0
* @author @lianlian.com
* @Date 2018-6-13 下午5:26:33
* @since JDK 1.6
 */
public class RegphoneVerifycodeVerifyReqDomain extends AbstractAPIReqDomain{

	/** */
	private static final long serialVersionUID = -9021873557738015084L;

	/**商户用户唯一编号*/
	private String user_id;
	/**注册手机号*/
	private String reg_phone;
	/**开户注册验证码*/
	private String verify_code;
	public String getUser_id() {
		return user_id;
	}
	public void setUser_id(String user_id) {
		this.user_id = user_id;
	}
	public String getReg_phone() {
		return reg_phone;
	}
	public void setReg_phone(String reg_phone) {
		this.reg_phone = reg_phone;
	}
	public String getVerify_code() {
		return verify_code;
	}
	public void setVerify_code(String verify_code) {
		this.verify_code = verify_code;
	}
	
}
