/**
 * Copyright © 2004-2018 LianlianPay.All Rights Reserved.
 */
package com.accp.demo.openaccount.domain;

import com.accp.demo.openaccount.domain.AbstractAPIResDomain;


/**
 * 
* 描述说明
* 验证注册手机号返回bean
* @version V1.0
* @author @lianlian.com
* @Date 2018-6-13 下午5:27:21
* @since JDK 1.6
 */
public class RegphoneVerifycodeVerifyResDomain extends AbstractAPIResDomain{

	/** */
	private static final long serialVersionUID = -7980517318197494121L;

	/**商户用户唯一编号*/
	private String user_id;
	
	/**商户号*/
	private String oid_partner;
	
	/**注册手机号*/
	private String reg_phone;

	public String getUser_id() {
		return user_id;
	}

	public void setUser_id(String user_id) {
		this.user_id = user_id;
	}

	public String getOid_partner() {
		return oid_partner;
	}

	public void setOid_partner(String oid_partner) {
		this.oid_partner = oid_partner;
	}

	public String getReg_phone() {
		return reg_phone;
	}

	public void setReg_phone(String reg_phone) {
		this.reg_phone = reg_phone;
	}
	
}
