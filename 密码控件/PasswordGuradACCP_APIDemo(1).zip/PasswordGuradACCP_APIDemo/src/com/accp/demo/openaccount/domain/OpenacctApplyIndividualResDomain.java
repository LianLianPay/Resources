/**
 * Copyright © 2004-2018 LianlianPay.All Rights Reserved.
 */
package com.accp.demo.openaccount.domain;

import com.accp.demo.openaccount.domain.AbstractAPIResDomain;

/**
 * 
* 描述说明
* 个人开户 向银行预留手机号发送短信返回bean
* @version V1.0
* @author @lianlian.com
* @Date 2018-6-7 上午11:01:05
* @since JDK 1.6
 */
public class OpenacctApplyIndividualResDomain extends AbstractAPIResDomain{

	/** */
	private static final long serialVersionUID = 3228954094727232335L;
	/**商户*/
	private String oid_partner;
	/**商户用户唯一编号*/
	private String user_id;
	/**交易流水号*/
	private String txn_seqno;
	/**ACCP系统交易单号*/
	private String accp_txno;
	/**授权令牌*/
	private String token;
	public String getOid_partner() {
		return oid_partner;
	}
	public void setOid_partner(String oid_partner) {
		this.oid_partner = oid_partner;
	}
	public String getUser_id() {
		return user_id;
	}
	public void setUser_id(String user_id) {
		this.user_id = user_id;
	}
	public String getTxn_seqno() {
		return txn_seqno;
	}
	public void setTxn_seqno(String txn_seqno) {
		this.txn_seqno = txn_seqno;
	}
	public String getAccp_txno() {
		return accp_txno;
	}
	public void setAccp_txno(String accp_txno) {
		this.accp_txno = accp_txno;
	}
	public String getToken() {
		return token;
	}
	public void setToken(String token) {
		this.token = token;
	}

}
