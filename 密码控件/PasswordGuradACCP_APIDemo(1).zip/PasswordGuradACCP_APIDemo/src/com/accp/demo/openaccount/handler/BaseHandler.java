package com.accp.demo.openaccount.handler;


public abstract class BaseHandler {

	public static String SYSERROR_CODE = "9999";
	public static String SYSERROR_MSG = "系统繁忙，请稍后重试";
	
	public static String SYSSUCC_CODE = "0000";
	public static String SYSSUCC_MSG = "交易成功";
	
//	protected static String test_domainurl = "https://accptest.lianlianpay.com/openapi/";
	protected static String test_domainurl = "https://accptest.lianlianpay-inc.com/openapi/";
}

