/**
 * Copyright © 2004-2018 LianlianPay.All Rights Reserved.
 */
package com.accp.demo.openaccount.domain;

import com.accp.demo.openaccount.domain.AbstractAPIReqDomain;

/**
 * 
* 描述说明
* 个人开户 向预留手机号发送短信请求bean
* @version V1.0
* @author @lianlian.com
* @Date 2018-6-7 上午11:00:29
* @since JDK 1.6
 */
public class OpenacctApplyIndividualReqDomain extends AbstractAPIReqDomain{

	/** */
	private static final long serialVersionUID = 3623075964644852682L;

	/**商户用户唯一编号*/
	private String user_id;
	/**交易流水号*/
	private String txn_seqno;
	/**交易时间 yyyyMMddHHmmss*/
	private String txn_time;
	/**异步通知地址*/
	private String notify_url;
	/**开户标识是否银行开户0：否       1：是；默认是1*/
	private String open_flag;
	private BasicInfo basicInfo;
	private LinkedAcctInfo linkedAcctInfo;
	public String getUser_id() {
		return user_id;
	}
	public void setUser_id(String user_id) {
		this.user_id = user_id;
	}
	public String getTxn_seqno() {
		return txn_seqno;
	}
	public void setTxn_seqno(String txn_seqno) {
		this.txn_seqno = txn_seqno;
	}
	public String getTxn_time() {
		return txn_time;
	}
	public void setTxn_time(String txn_time) {
		this.txn_time = txn_time;
	}
	public String getNotify_url() {
		return notify_url;
	}
	public void setNotify_url(String notify_url) {
		this.notify_url = notify_url;
	}
	public BasicInfo getBasicInfo() {
		return basicInfo;
	}
	public void setBasicInfo(BasicInfo basicInfo) {
		this.basicInfo = basicInfo;
	}
	public LinkedAcctInfo getLinkedAcctInfo() {
		return linkedAcctInfo;
	}
	public void setLinkedAcctInfo(LinkedAcctInfo linkedAcctInfo) {
		this.linkedAcctInfo = linkedAcctInfo;
	}
	public String getOpen_flag() {
		return open_flag;
	}
	public void setOpen_flag(String open_flag) {
		this.open_flag = open_flag;
	}
	
	
}
