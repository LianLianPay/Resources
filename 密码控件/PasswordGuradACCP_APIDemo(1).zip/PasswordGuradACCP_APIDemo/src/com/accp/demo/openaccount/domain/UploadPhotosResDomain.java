/**
 * Copyright © 2004-2018 LianlianPay.All Rights Reserved.
 */
package com.accp.demo.openaccount.domain;

/***
 * 
* 描述说明
* 上传照片返回bean
* @version V1.0
* @author @lianlian.com
* @Date 2018-6-8 下午5:01:59
* @since JDK 1.6
 */
public class UploadPhotosResDomain extends AbstractAPIResDomain{

	/** */
	private static final long serialVersionUID = 7934155565232768889L;

	/**商户号*/
	private String oid_partner;
	/**用户号*/
	private String user_id;
	public String getOid_partner() {
		return oid_partner;
	}
	public void setOid_partner(String oid_partner) {
		this.oid_partner = oid_partner;
	}
	public String getUser_id() {
		return user_id;
	}
	public void setUser_id(String user_id) {
		this.user_id = user_id;
	}
}
