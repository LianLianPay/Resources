/**
 * Copyright © 2004-2018 LianlianPay.All Rights Reserved.
 */
package com.accp.demo.openaccount.domain;

import com.accp.demo.openaccount.domain.AbstractAPIReqDomain;
/**
 * 
* 描述说明
* 个人开户 银行预留手机号验证请求bean
* @version V1.0
* @author @lianlian.com
* @Date 2018-6-7 上午10:59:14
* @since JDK 1.6
 */
public class OpenacctVerifyIndividualReqDomain extends AbstractAPIReqDomain{

	/** */
	private static final long serialVersionUID = -4746439242202008087L;
	
	private String user_id;
	/**交易流水号*/
	private String txn_seqno;
	/**授权令牌*/
	private String token;
	/**验证码*/
	private String verify_code;
	private String password;
	/**随机因子key*/
	private String random_key;
	public String getUser_id() {
		return user_id;
	}
	public void setUser_id(String user_id) {
		this.user_id = user_id;
	}
	public String getTxn_seqno() {
		return txn_seqno;
	}
	public void setTxn_seqno(String txn_seqno) {
		this.txn_seqno = txn_seqno;
	}
	public String getToken() {
		return token;
	}
	public void setToken(String token) {
		this.token = token;
	}
	public String getVerify_code() {
		return verify_code;
	}
	public void setVerify_code(String verify_code) {
		this.verify_code = verify_code;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getRandom_key() {
		return random_key;
	}
	public void setRandom_key(String random_key) {
		this.random_key = random_key;
	}
	
	
}
