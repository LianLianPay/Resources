/**
 * Copyright © 2004-2018 LianlianPay.All Rights Reserved.
 */
package com.accp.demo.openaccount.domain;

import java.io.Serializable;

/**
 * 
* 描述说明
* 企业法定代表人信息legalreptInfo
* @version V1.0
* @author @lianlian.com
* @Date 2018-5-31 下午7:50:27
* @since JDK 1.6
 */
public class LegalreptInfo implements Serializable{

	/** */
	private static final long serialVersionUID = 3341031901177781594L;

	/**法定代表人姓名*/
	private String legalrept_name;
	/**法定代表人手机号*/
	private String legalrept_phone;
	/**法定代表人身份证号*/
	private String legalrept_idno;
	/**法定代表人身份证有效期*/
	private String legalrept_idexp;
	public String getLegalrept_name() {
		return legalrept_name;
	}
	public void setLegalrept_name(String legalrept_name) {
		this.legalrept_name = legalrept_name;
	}
	public String getLegalrept_phone() {
		return legalrept_phone;
	}
	public void setLegalrept_phone(String legalrept_phone) {
		this.legalrept_phone = legalrept_phone;
	}
	public String getLegalrept_idno() {
		return legalrept_idno;
	}
	public void setLegalrept_idno(String legalrept_idno) {
		this.legalrept_idno = legalrept_idno;
	}
	public String getLegalrept_idexp() {
		return legalrept_idexp;
	}
	public void setLegalrept_idexp(String legalrept_idexp) {
		this.legalrept_idexp = legalrept_idexp;
	}
	
}
