/**
 * Copyright © 2004-2018 LianlianPay.All Rights Reserved.
 */
package com.accp.demo.openaccount.domain;

import java.io.Serializable;

/**
 * 
* 描述说明
* 企业经营信息businessInfo
* @version V1.0
* @author @lianlian.com
* @Date 2018-5-31 下午7:52:51
* @since JDK 1.6
 */
public class BusinessInfo implements Serializable{

	/** */
	private static final long serialVersionUID = -6821994807898245232L;
	/**企业规模*/
	private String scale;
	/**行业代码*/
	private String industry_code;
	/**注册资本*/
	private String registered_capital;
	/**经营范围*/
	private String business_scope;
	public String getScale() {
		return scale;
	}
	public void setScale(String scale) {
		this.scale = scale;
	}
	public String getIndustry_code() {
		return industry_code;
	}
	public void setIndustry_code(String industry_code) {
		this.industry_code = industry_code;
	}
	public String getRegistered_capital() {
		return registered_capital;
	}
	public void setRegistered_capital(String registered_capital) {
		this.registered_capital = registered_capital;
	}
	public String getBusiness_scope() {
		return business_scope;
	}
	public void setBusiness_scope(String business_scope) {
		this.business_scope = business_scope;
	}
	
	
}
