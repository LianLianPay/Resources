/**
 * Copyright © 2004-2018 LianlianPay.All Rights Reserved.
 */
package com.accp.demo.openaccount.domain;

import java.io.Serializable;
/**
 * 
* 描述说明
* 开户绑卡信息linkedAcctInfo
* @version V1.0
* @author @lianlian.com
* @Date 2018-5-31 下午7:47:16
* @since JDK 1.6
 */
public class LinkedAcctInfo implements Serializable{

	/** */
	private static final long serialVersionUID = 3053747982169223169L;

	/**绑定银行帐号*/
	private String linked_acctno;
	/**银行编码*/
	private String linked_bankcode;
	/**对公账户开户行号*/
	private String linked_brbankno;
	/**对公账户开户行名*/
	private String linked_brbankname;
	/**银行预留手机号*/
	private String linked_phone;
	/**对公账户名*/
	private String linked_acctname;
	/**信用卡cvv2*/
	private String cvv2;
	/**信用卡有效期*/
	private String valid_thru;
	
	/**绑卡协议号*/
	private String linked_agrtno;
	public String getLinked_acctno() {
		return linked_acctno;
	}
	public void setLinked_acctno(String linked_acctno) {
		this.linked_acctno = linked_acctno;
	}
	public String getLinked_bankcode() {
		return linked_bankcode;
	}
	public void setLinked_bankcode(String linked_bankcode) {
		this.linked_bankcode = linked_bankcode;
	}
	public String getLinked_brbankno() {
		return linked_brbankno;
	}
	public void setLinked_brbankno(String linked_brbankno) {
		this.linked_brbankno = linked_brbankno;
	}
	public String getLinked_brbankname() {
		return linked_brbankname;
	}
	public void setLinked_brbankname(String linked_brbankname) {
		this.linked_brbankname = linked_brbankname;
	}
	public String getLinked_phone() {
		return linked_phone;
	}
	public void setLinked_phone(String linked_phone) {
		this.linked_phone = linked_phone;
	}
	public String getLinked_acctname() {
		return linked_acctname;
	}
	public void setLinked_acctname(String linked_acctname) {
		this.linked_acctname = linked_acctname;
	}
	public String getLinked_agrtno() {
		return linked_agrtno;
	}
	public void setLinked_agrtno(String linked_agrtno) {
		this.linked_agrtno = linked_agrtno;
	}
	public String getCvv2() {
		return cvv2;
	}
	public void setCvv2(String cvv2) {
		this.cvv2 = cvv2;
	}
	public String getValid_thru() {
		return valid_thru;
	}
	public void setValid_thru(String valid_thru) {
		this.valid_thru = valid_thru;
	}
	
}
