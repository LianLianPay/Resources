/**
 * Copyright © 2004-2018 LianlianPay.All Rights Reserved.
 */
package com.accp.demo.openaccount.domain;

/***
 * 
* 描述说明
* 上传照片请求bean
* @version V1.0
* @author @lianlian.com
* @Date 2018-6-8 下午4:44:00
* @since JDK 1.6
 */
public class UploadPhotosReqDomain extends AbstractAPIReqDomain{

	/** */
	private static final long serialVersionUID = 1225703344657737957L;

	/**用户唯一编号*/
	private String user_id;
	/**身份证国徽面*/
	private String id_emblem;
	/**身份证人像面*/
	private String id_portrait;
	/**统一社会信用代码证 三证合一证件照*/
	private String unified_code;
	/**身份证国文件类型*/
	private String id_filetype;
	/**统一社会信用代码证三证合一证件照*/
	private String unified_code_filetype;
	public String getUser_id() {
		return user_id;
	}
	public void setUser_id(String user_id) {
		this.user_id = user_id;
	}
	public String getId_emblem() {
		return id_emblem;
	}
	public void setId_emblem(String id_emblem) {
		this.id_emblem = id_emblem;
	}
	public String getId_portrait() {
		return id_portrait;
	}
	public void setId_portrait(String id_portrait) {
		this.id_portrait = id_portrait;
	}
	public String getUnified_code() {
		return unified_code;
	}
	public void setUnified_code(String unified_code) {
		this.unified_code = unified_code;
	}
	public String getId_filetype() {
		return id_filetype;
	}
	public void setId_filetype(String id_filetype) {
		this.id_filetype = id_filetype;
	}
	public String getUnified_code_filetype() {
		return unified_code_filetype;
	}
	public void setUnified_code_filetype(String unified_code_filetype) {
		this.unified_code_filetype = unified_code_filetype;
	}
	
}
