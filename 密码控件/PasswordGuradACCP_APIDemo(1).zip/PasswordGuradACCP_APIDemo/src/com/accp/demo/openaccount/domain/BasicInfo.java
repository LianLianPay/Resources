/**
 * Copyright © 2004-2018 LianlianPay.All Rights Reserved.
 */
package com.accp.demo.openaccount.domain;

import java.io.Serializable;
/**
 * 
* 描述说明
* 开户基本信息basicInfo
* @version V1.0
* @author @lianlian.com
* @Date 2018-5-31 下午7:47:26
* @since JDK 1.6
 */
public class BasicInfo implements Serializable{

	/** */
	private static final long serialVersionUID = 208018510264914161L;

	/**绑定手机号*/
//	@VALIDATOR_PHONE_NO(required=false,message="请输入正确的绑定手机号")
	private String reg_phone;
	/**用户名称*/
//	@VALIDATOR_NAME(required=false)
	private String user_name;
	/**证件类型*/
	private String id_type;
	/**证件号码*/
//	@VALIDATOR_ID_NO()
	private String id_no;
	/**证件有效期*/
	private String id_exp;
	/**地址*/
	private String address;
	/**注册邮箱*/
	private String reg_email;
	/**职业*/
	private String occupation;
	
	/**开户注册验证码*/
	private String reg_phone_verifycode;
	
	/**密码*/
	private String password;
	/**随机因子key*/
	private String random_key;
	public String getReg_phone() {
		return reg_phone;
	}
	public void setReg_phone(String reg_phone) {
		this.reg_phone = reg_phone;
	}
	public String getUser_name() {
		return user_name;
	}
	public void setUser_name(String user_name) {
		this.user_name = user_name;
	}
	public String getId_no() {
		return id_no;
	}
	public void setId_no(String id_no) {
		this.id_no = id_no;
	}
	public String getId_exp() {
		return id_exp;
	}
	public void setId_exp(String id_exp) {
		this.id_exp = id_exp;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getReg_email() {
		return reg_email;
	}
	public void setReg_email(String reg_email) {
		this.reg_email = reg_email;
	}
	public String getOccupation() {
		return occupation;
	}
	public void setOccupation(String occupation) {
		this.occupation = occupation;
	}
	public String getId_type() {
		return id_type;
	}
	public void setId_type(String id_type) {
		this.id_type = id_type;
	}
	public String getReg_phone_verifycode() {
		return reg_phone_verifycode;
	}
	public void setReg_phone_verifycode(String reg_phone_verifycode) {
		this.reg_phone_verifycode = reg_phone_verifycode;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getRandom_key() {
		return random_key;
	}
	public void setRandom_key(String random_key) {
		this.random_key = random_key;
	}
	
}
