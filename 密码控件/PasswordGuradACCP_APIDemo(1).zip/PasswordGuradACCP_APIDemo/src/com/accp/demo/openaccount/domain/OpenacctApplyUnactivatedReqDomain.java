/**
 * Copyright © 2004-2018 LianlianPay.All Rights Reserved.
 */
package com.accp.demo.openaccount.domain;

import com.accp.demo.openaccount.domain.AbstractAPIReqDomain;
/**
 * 
* 描述说明
* 待激活开户请求bean
* @version V1.0
* @author @lianlian.com
* @Date 2018-6-7 上午11:01:41
* @since JDK 1.6
 */
public class OpenacctApplyUnactivatedReqDomain extends AbstractAPIReqDomain{

	/** */
	private static final long serialVersionUID = -9071674847973138832L;

	/**商户用户唯一编号*/
	private String user_id;
	/**交易流水号*/
	private String txn_seqno;
	/**交易时间 yyyyMMddHHmmss*/
	private String txn_time;
	/**异步通知地址*/
	private String notify_url;
	/**用户类型 个人：INDIVIDUAL企业：ENTERPRISE*/
	private String user_type;

	/**开户基本信息*/
	private BasicInfo basicInfo;
	/**开户绑卡信息*/
	private LinkedAcctInfo linkedAcctInfo;
	/**企业法定代表人信息*/
	private LegalreptInfo legalreptInfo;
	/**企业联系人信息*/
	private ContactsInfo contactsInfo;
	/**企业经营信息*/
	private BusinessInfo businessInfo;
	/**企业基本户信息*/
	private BasicAcctInfo basicAcctInfo;
	public String getUser_id() {
		return user_id;
	}
	public void setUser_id(String user_id) {
		this.user_id = user_id;
	}
	public String getTxn_seqno() {
		return txn_seqno;
	}
	public void setTxn_seqno(String txn_seqno) {
		this.txn_seqno = txn_seqno;
	}
	public String getTxn_time() {
		return txn_time;
	}
	public void setTxn_time(String txn_time) {
		this.txn_time = txn_time;
	}
	public String getNotify_url() {
		return notify_url;
	}
	public void setNotify_url(String notify_url) {
		this.notify_url = notify_url;
	}
	public String getUser_type() {
		return user_type;
	}
	public void setUser_type(String user_type) {
		this.user_type = user_type;
	}
	public BasicInfo getBasicInfo() {
		return basicInfo;
	}
	public void setBasicInfo(BasicInfo basicInfo) {
		this.basicInfo = basicInfo;
	}
	public LinkedAcctInfo getLinkedAcctInfo() {
		return linkedAcctInfo;
	}
	public void setLinkedAcctInfo(LinkedAcctInfo linkedAcctInfo) {
		this.linkedAcctInfo = linkedAcctInfo;
	}
	public LegalreptInfo getLegalreptInfo() {
		return legalreptInfo;
	}
	public void setLegalreptInfo(LegalreptInfo legalreptInfo) {
		this.legalreptInfo = legalreptInfo;
	}
	public ContactsInfo getContactsInfo() {
		return contactsInfo;
	}
	public void setContactsInfo(ContactsInfo contactsInfo) {
		this.contactsInfo = contactsInfo;
	}
	public BusinessInfo getBusinessInfo() {
		return businessInfo;
	}
	public void setBusinessInfo(BusinessInfo businessInfo) {
		this.businessInfo = businessInfo;
	}
	public BasicAcctInfo getBasicAcctInfo() {
		return basicAcctInfo;
	}
	public void setBasicAcctInfo(BasicAcctInfo basicAcctInfo) {
		this.basicAcctInfo = basicAcctInfo;
	}
	
	
	
}
