/**
 * Copyright © 2004-2018 LianlianPay.All Rights Reserved.
 */
package com.accp.demo.openaccount.domain;

import com.accp.demo.openaccount.domain.AbstractAPIReqDomain;

/**
 * 
* 描述说明
* 标准开户 3.3.	绑定手机验证码申请请求bean
* @version V1.0
* @author @lianlian.com
* @Date 2018-6-7 上午11:03:18
* @since JDK 1.6
 */
public class RegphoneVerifycodeApplyReqDomain extends AbstractAPIReqDomain{

	/** */
	private static final long serialVersionUID = -9187473632563632525L;

	/**商户用户唯一编号*/
	private String user_id;
	/**注册手机号*/
	private String reg_phone;
	public String getUser_id() {
		return user_id;
	}
	public void setUser_id(String user_id) {
		this.user_id = user_id;
	}
	public String getReg_phone() {
		return reg_phone;
	}
	public void setReg_phone(String reg_phone) {
		this.reg_phone = reg_phone;
	}
	
}
