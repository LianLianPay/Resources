/**
 * Copyright © 2004-2018 LianlianPay.All Rights Reserved.
 */
package com.accp.demo.openaccount.domain;
/**
 * 
* 描述说明
* 开户申请验证token信息
* @version V1.0
* @author @lianlian.com
* @Date 2018-6-16 下午5:35:53
* @since JDK 1.6
 */
public class OpenacctApplyIndividualToken extends OpenacctApplyIndividualReqDomain{

	/** */
	private static final long serialVersionUID = -3023231845240641261L;

	private String accp_txno;
	private String linked_agrtno;
	private String oid_userno;
	private boolean verfiy_reg_phone;
	private boolean verfiy_linked_phone;
	public String getAccp_txno() {
		return accp_txno;
	}
	public void setAccp_txno(String accp_txno) {
		this.accp_txno = accp_txno;
	}
	public String getLinked_agrtno() {
		return linked_agrtno;
	}
	public void setLinked_agrtno(String linked_agrtno) {
		this.linked_agrtno = linked_agrtno;
	}
	public String getOid_userno() {
		return oid_userno;
	}
	public void setOid_userno(String oid_userno) {
		this.oid_userno = oid_userno;
	}
	public boolean isVerfiy_reg_phone() {
		return verfiy_reg_phone;
	}
	public void setVerfiy_reg_phone(boolean verfiy_reg_phone) {
		this.verfiy_reg_phone = verfiy_reg_phone;
	}
	public boolean isVerfiy_linked_phone() {
		return verfiy_linked_phone;
	}
	public void setVerfiy_linked_phone(boolean verfiy_linked_phone) {
		this.verfiy_linked_phone = verfiy_linked_phone;
	}
	
	
}
