package com.accp.demo.openaccount.test;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;

import org.junit.Ignore;
import org.junit.Test;

import com.accp.demo.openaccount.domain.BankacctApplyIndividualReqDomain;
import com.accp.demo.openaccount.domain.BasicAcctInfo;
import com.accp.demo.openaccount.domain.BasicInfo;
import com.accp.demo.openaccount.domain.BusinessInfo;
import com.accp.demo.openaccount.domain.ContactsInfo;
import com.accp.demo.openaccount.domain.LegalreptInfo;
import com.accp.demo.openaccount.domain.LinkedAcctInfo;
import com.accp.demo.openaccount.domain.OpenacctApplyEnterpriseReqDomain;
import com.accp.demo.openaccount.domain.OpenacctApplyIndividualReqDomain;
import com.accp.demo.openaccount.domain.OpenacctVerifyIndividualReqDomain;
import com.accp.demo.openaccount.domain.RegphoneVerifycodeApplyReqDomain;
import com.accp.demo.openaccount.domain.RegphoneVerifycodeApplyResDomain;
import com.accp.demo.openaccount.domain.RegphoneVerifycodeVerifyReqDomain;
import com.accp.demo.openaccount.domain.RegphoneVerifycodeVerifyResDomain;
import com.accp.demo.openaccount.domain.UploadPhotosReqDomain;
import com.accp.demo.openaccount.handler.OpenAccountHandler;
import com.accp.demo.util.DateUtil;

/**
 * 开户测试工具类
 * @author wuzf
 *
 */
public class TestOpenAccont {

	public static String oid_partner = "201801120000283006";
	public static String user_id = "20180917143007";
	/**
	 * 向注册手机号发送短信
	 */
	@Test
//	@Ignore
	public void sendRegphoneSms(){
		/**
		 * 注册手机号发送短信
		 */
		RegphoneVerifycodeApplyReqDomain regphoneVerifycodeApplyReqDomain = new RegphoneVerifycodeApplyReqDomain();
		regphoneVerifycodeApplyReqDomain.setOid_partner(oid_partner);
		regphoneVerifycodeApplyReqDomain.setUser_id(user_id);
		regphoneVerifycodeApplyReqDomain.setReg_phone("17606716561");
		regphoneVerifycodeApplyReqDomain.setTimestamp(DateUtil.getCurrentDateTimeStr1());
		RegphoneVerifycodeApplyResDomain regphoneVerifycodeApplyResDomain = OpenAccountHandler.sendRegphoneSms(regphoneVerifycodeApplyReqDomain);
		if(!OpenAccountHandler.SYSSUCC_CODE.equals(regphoneVerifycodeApplyResDomain.getRet_code())){
			return;
		}
		/**
		 * 成功处理
		 */
	}
	
	/**
	 * 验证注册手机号
	 */
	@Test
	@Ignore
	public void verifyRegphoneSms(){
		RegphoneVerifycodeVerifyReqDomain request = new RegphoneVerifycodeVerifyReqDomain();
		request.setOid_partner(oid_partner);
		request.setReg_phone("17606716561");
		request.setTimestamp(DateUtil.getCurrentDateTimeStr1());
		request.setVerify_code("337452");
		request.setUser_id(user_id);
		RegphoneVerifycodeVerifyResDomain response = OpenAccountHandler.verifyRegphoneSms(request);
		if(!OpenAccountHandler.SYSSUCC_CODE.equals(response.getRet_code())){
			return;
		}
	}
	
	/**
	 * 个人开户 申请
	 */
	@Test
	@Ignore
	public void individualBankCardApply(){
		OpenacctApplyIndividualReqDomain request = new OpenacctApplyIndividualReqDomain();
		BasicInfo basicInfo = new BasicInfo();
		basicInfo.setId_no("410527198704096718");
		basicInfo.setId_type("ID_CARD");
		basicInfo.setUser_name("吴志飞");
		basicInfo.setReg_phone("17606716561");
		basicInfo.setOccupation("01");
		basicInfo.setReg_email("wuzf@yintong.com.cn");
		basicInfo.setAddress("越达巷79号连连控件10楼");
		basicInfo.setReg_phone_verifycode("231241");
		basicInfo.setId_exp("99991221");
		request.setBasicInfo(basicInfo);
		LinkedAcctInfo linkedAcctInfo = new LinkedAcctInfo();
		linkedAcctInfo.setLinked_acctname("吴志飞");
		linkedAcctInfo.setLinked_acctno("6212261202035029422");
		linkedAcctInfo.setLinked_bankcode("01020000");
		linkedAcctInfo.setLinked_brbankname("工商银行彩虹城支行");
//		linkedAcctInfo.setLinked_brbankno("111111");
		linkedAcctInfo.setLinked_phone("17606716561");
		
		request.setLinkedAcctInfo(linkedAcctInfo);
		request.setNotify_url("https://www.baidu.com");
		request.setOid_partner(oid_partner);
		request.setTimestamp(DateUtil.getCurrentDateTimeStr1());
		request.setTxn_seqno("accp" + DateUtil.getCurrentDateTimeStr1());
		request.setTxn_time(DateUtil.getCurrentDateTimeStr1());
		request.setUser_id(user_id);
		request.setOpen_flag("1");
		OpenAccountHandler.individualBankCardApply(request);
	}
	
	/**
	 * 个人开户验证
	 */
	@Test
	@Ignore
	public void individualBankCardVerify(){
		OpenacctVerifyIndividualReqDomain request = new OpenacctVerifyIndividualReqDomain();
		request.setOid_partner(oid_partner);
		//TODO 通过WEB或H5端获取密码密文
//		request.setPassword("YXzf1BMpgmE2+zPMy0sGLDC8E7KNeoSEtkoZbi2701FER9iLf4WRfgiDo6R6IvL8XMAvGohTEXjen92evgniLO3e2M8pFqPSrCxkSlNc/jwVQZDX3UE85qNAhLbcNYjVDRCfGV1zXze0Yc8chrb30EScFl3nUIwU9NvfWvupW5UJAvTnY8EIcrEZWvuF93QwkmxxI/c9ZiaEjBxTUYf2fldzv6CIQFxTQlsaZkSr9uqOObJWK8PFDzJfLfSYIFzqw2xOKFF3sgpT2nX3xifBOeCiHX31ZHBRX2NLQBaLqVPP9N2dZ67k/gY7sEHtka9PKbddafMNfV4L48F4tQ8JkA2cG7dsf8I2IyoQXrRvRpxXgo8lR6UNw1MfbvQZc4G7ra3L4fYnIQjRm+sJ7Ajgc8stAXvceTIvd3n6tMVSOf3+/FC4/TYpxWEgebUHHyCA5nSJowXuavHypUySBXh8Mw==");
//		request.setRandom_key("727b1ee3-424c-435e-8a2c-7832449c7447");
		request.setPassword("123123");
		request.setTimestamp(DateUtil.getCurrentDateTimeStr1());
		request.setToken("4b49bd73be47ef9b128216e25c9df763");
		request.setTxn_seqno("accp20180917153358");
		request.setVerify_code("157215");
		request.setUser_id(user_id);
		OpenAccountHandler.individualBankCardVerify(request);
	}
	
	/**
	 * 银行开户
	 */
	@Test
	@Ignore
	public void openBankAccount(){
		BankacctApplyIndividualReqDomain request = new BankacctApplyIndividualReqDomain();
		request.setOid_partner(oid_partner);
		request.setTimestamp(DateUtil.getCurrentDateTimeStr1());
		request.setTxn_seqno("wzf" + DateUtil.getCurrentDateTimeStr1());
		request.setTxn_time(DateUtil.getCurrentDateTimeStr1());
		request.setUser_id(user_id);
		OpenAccountHandler.openBankAccount(request);
	}
	
	/**
	 * 企业开户
	 */
	@Test
	@Ignore
	public void enterpriseOpen(){
		OpenacctApplyEnterpriseReqDomain request = new OpenacctApplyEnterpriseReqDomain();
		BasicAcctInfo basicAcctInfo = new BasicAcctInfo();
		basicAcctInfo.setBasicacct_bankcode("01020000");
		basicAcctInfo.setBasicacct_no("12121212");
		request.setBasicAcctInfo(basicAcctInfo);
		
		BasicInfo basicInfo = new BasicInfo();
		basicInfo.setId_no("410527198704096718");
		basicInfo.setId_type("UNIFIED_SOCIAL_CREDIT_CODE");
		basicInfo.setUser_name("吴志飞");
		basicInfo.setReg_phone("17606716561");
		basicInfo.setOccupation("01");
		basicInfo.setReg_email("wuzf@yintong.com.cn");
		basicInfo.setAddress("越达巷79号连连控件10楼");
		basicInfo.setPassword("123123");
		basicInfo.setId_exp("20190102");
		request.setBasicInfo(basicInfo);
		
		BusinessInfo businessInfo = new BusinessInfo();
		businessInfo.setBusiness_scope("挖掘机");
		businessInfo.setIndustry_code("340");
		businessInfo.setRegistered_capital("20000");
		businessInfo.setScale("LARGE");
		request.setBusinessInfo(businessInfo);
		
		ContactsInfo contactsInfo = new ContactsInfo();
		contactsInfo.setContacts_name("吴志飞");
		contactsInfo.setContacts_phone(user_id);
		request.setContactsInfo(contactsInfo);
		
		LegalreptInfo legalreptInfo = new LegalreptInfo();
		legalreptInfo.setLegalrept_idexp("20201012");
		legalreptInfo.setLegalrept_idno("410527198704096718");
		legalreptInfo.setLegalrept_name("吴志飞");
		legalreptInfo.setLegalrept_phone(user_id);
		request.setLegalreptInfo(legalreptInfo);
		
		LinkedAcctInfo linkedAcctInfo = new LinkedAcctInfo();
		linkedAcctInfo.setLinked_acctname("企业测试");
		linkedAcctInfo.setLinked_acctno("12121212");
		linkedAcctInfo.setLinked_bankcode("01020000");
		linkedAcctInfo.setLinked_brbankname("工商银行滨江支行");
		linkedAcctInfo.setLinked_brbankno("123456781231");
		linkedAcctInfo.setLinked_phone(user_id);
		request.setLinkedAcctInfo(linkedAcctInfo);
		
		request.setNotify_url("https://www.baidu.com");
		request.setOid_partner(oid_partner);
		request.setTxn_time(DateUtil.getCurrentDateTimeStr1());
		request.setTimestamp(DateUtil.getCurrentDateTimeStr1());
		request.setTxn_seqno(DateUtil.getCurrentDateTimeStr1());
		request.setUser_id(user_id);
		OpenAccountHandler.enterpriseOpen(request);
	}
	
	/**
	 * 上传照片
	 * @throws Exception
	 */
	@Test
	@Ignore
	public void uploadPhotos() throws Exception{
		UploadPhotosReqDomain request = new UploadPhotosReqDomain();
		request.setOid_partner(oid_partner);
		request.setTimestamp(DateUtil.getCurrentDateTimeStr1());
		File file1 = new File("D:/temp/wzf_b.jpg");
		InputStream input1 = new FileInputStream(file1);
		byte[] byt1 = new byte[input1.available()];
		input1.read(byt1);
		request.setId_emblem(com.accp.demo.util.Base64.getBASE64(byt1));
		input1.close();
		File file2 = new File("D:/temp/wzf_f.jpg");
		InputStream input2 = new FileInputStream(file2);
		byte[] byt2 = new byte[input2.available()];
		input2.read(byt2);
		input2.close();
		request.setId_portrait(com.accp.demo.util.Base64.getBASE64(byt2));
		request.setId_filetype("jpg");
		
//		File file3 = new File("D:/temp/wzf_b1.png");
//		InputStream input3 = new FileInputStream(file3);
//		byte[] byt3 = new byte[input3.available()];
//		input3.read(byt3);
//		request.setUnified_code(Base64.getBASE64(byt3));
//		
//		request.setUnified_code_filetype("png");
		
//		request.setVerify_code("111233");
		OpenAccountHandler.uploadPhotos(request);
	}
}
 