/**
 * Copyright © 2004-2018 LianlianPay.All Rights Reserved.
 */
package com.accp.demo.openaccount.domain;

import java.io.Serializable;

/**
 * 
* 描述说明
* 企业基本户信息basicAcctInfo
* @version V1.0
* @author @lianlian.com
* @Date 2018-5-31 下午7:55:58
* @since JDK 1.6
 */
public class BasicAcctInfo implements Serializable{

	/** */
	private static final long serialVersionUID = 1095087640213375124L;
	
	/**基本户银行编码*/
	private String basicacct_bankcode;
	/**基本户账号*/
	private String basicacct_no;
	public String getBasicacct_bankcode() {
		return basicacct_bankcode;
	}
	public void setBasicacct_bankcode(String basicacct_bankcode) {
		this.basicacct_bankcode = basicacct_bankcode;
	}
	public String getBasicacct_no() {
		return basicacct_no;
	}
	public void setBasicacct_no(String basicacct_no) {
		this.basicacct_no = basicacct_no;
	}
	
	
}
