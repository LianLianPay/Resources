/**
 * Copyright © 2004-2018 LianlianPay.All Rights Reserved.
 */
package com.accp.demo.openaccount.domain;

import com.accp.demo.openaccount.domain.AbstractAPIResDomain;
/**
 * 
* 描述说明
* 标准开户 3.3.	绑定手机验证码申请返回bean
* @version V1.0
* @author @lianlian.com
* @Date 2018-6-1 下午2:02:13
* @since JDK 1.6
 */
public class RegphoneVerifycodeApplyResDomain extends AbstractAPIResDomain{

	/** */
	private static final long serialVersionUID = 7500192007901387130L;
	/**商户号*/
	private String oid_partner;
	/**交易结果代码*/
	private String ret_code;
	/**交易结果描述*/
	private String ret_msg;
	/**商户用户唯一编号*/
	private String user_id;
	/**绑定手机号*/
	private String reg_phone;
	/**授权令牌*/
	private String token;
	public String getOid_partner() {
		return oid_partner;
	}
	public void setOid_partner(String oid_partner) {
		this.oid_partner = oid_partner;
	}
	public String getRet_code() {
		return ret_code;
	}
	public void setRet_code(String ret_code) {
		this.ret_code = ret_code;
	}
	public String getRet_msg() {
		return ret_msg;
	}
	public void setRet_msg(String ret_msg) {
		this.ret_msg = ret_msg;
	}
	public String getUser_id() {
		return user_id;
	}
	public void setUser_id(String user_id) {
		this.user_id = user_id;
	}
	public String getReg_phone() {
		return reg_phone;
	}
	public void setReg_phone(String reg_phone) {
		this.reg_phone = reg_phone;
	}
	public String getToken() {
		return token;
	}
	public void setToken(String token) {
		this.token = token;
	}
	
}
