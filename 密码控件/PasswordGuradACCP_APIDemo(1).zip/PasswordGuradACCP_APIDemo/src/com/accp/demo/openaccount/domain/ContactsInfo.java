/**
 * Copyright © 2004-2018 LianlianPay.All Rights Reserved.
 */
package com.accp.demo.openaccount.domain;

import java.io.Serializable;

/**
 * 
* 描述说明
* 企业联系人信息contactsInfo
* @version V1.0
* @author @lianlian.com
* @Date 2018-5-31 下午7:51:13
* @since JDK 1.6
 */
public class ContactsInfo implements Serializable{

	/** */
	private static final long serialVersionUID = 1883810371361645736L;
	/**联系人姓名*/
	private String contacts_name;
	/**联系人手机号*/
	private String contacts_phone;
	public String getContacts_name() {
		return contacts_name;
	}
	public void setContacts_name(String contacts_name) {
		this.contacts_name = contacts_name;
	}
	public String getContacts_phone() {
		return contacts_phone;
	}
	public void setContacts_phone(String contacts_phone) {
		this.contacts_phone = contacts_phone;
	}
	
	
}
