/**
 * Copyright © 2004-2018 LianlianPay.All Rights Reserved.
 */
package com.accp.demo.openaccount.domain;

import com.accp.demo.openaccount.domain.AbstractAPIResDomain;

public class BankacctApplyIndividualResDomain extends AbstractAPIResDomain{

	/** */
	private static final long serialVersionUID = -1031557217555680334L;
	
	/**商户用户唯一编号*/
	private String user_id;
	
	/**商户号*/
	private String oid_partner;
	/**交易流水号*/
	private String txn_seqno;
	/**ACCP系统交易单号*/
	private String accp_txno;
	/**银行开户状态*/
	private String bank_open_flag;
	
	public String getBank_open_flag() {
		return bank_open_flag;
	}
	
	public void setBank_open_flag(String bank_open_flag) {
		this.bank_open_flag = bank_open_flag;
	}
	public String getUser_id() {
		return user_id;
	}
	public void setUser_id(String user_id) {
		this.user_id = user_id;
	}
	public String getOid_partner() {
		return oid_partner;
	}
	public void setOid_partner(String oid_partner) {
		this.oid_partner = oid_partner;
	}
	public String getTxn_seqno() {
		return txn_seqno;
	}
	public void setTxn_seqno(String txn_seqno) {
		this.txn_seqno = txn_seqno;
	}
	public String getAccp_txno() {
		return accp_txno;
	}
	public void setAccp_txno(String accp_txno) {
		this.accp_txno = accp_txno;
	}

}
