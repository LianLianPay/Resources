package com.accp.demo.openaccount.handler;

import com.accp.demo.http.util.RequestUtils;
import com.accp.demo.openaccount.domain.BankacctApplyIndividualReqDomain;
import com.accp.demo.openaccount.domain.BankacctApplyIndividualResDomain;
import com.accp.demo.openaccount.domain.OpenacctApplyEnterpriseReqDomain;
import com.accp.demo.openaccount.domain.OpenacctApplyEnterpriseResDomain;
import com.accp.demo.openaccount.domain.OpenacctApplyIndividualReqDomain;
import com.accp.demo.openaccount.domain.OpenacctApplyIndividualResDomain;
import com.accp.demo.openaccount.domain.OpenacctVerifyIndividualReqDomain;
import com.accp.demo.openaccount.domain.OpenacctVerifyIndividualResDomain;
import com.accp.demo.openaccount.domain.RegphoneVerifycodeApplyReqDomain;
import com.accp.demo.openaccount.domain.RegphoneVerifycodeApplyResDomain;
import com.accp.demo.openaccount.domain.RegphoneVerifycodeVerifyReqDomain;
import com.accp.demo.openaccount.domain.RegphoneVerifycodeVerifyResDomain;
import com.accp.demo.openaccount.domain.UploadPhotosReqDomain;
import com.accp.demo.openaccount.domain.UploadPhotosResDomain;
import com.accp.demo.util.FuncUtils;
import com.alibaba.fastjson.JSON;
/**
 * 开户处理类
 * @author wuzf
 *
 */
public class OpenAccountHandler extends BaseHandler{
	
	/**
	 * 注册手机号发送短信
	 * @param request
	 * @return
	 */
	public static RegphoneVerifycodeApplyResDomain sendRegphoneSms(RegphoneVerifycodeApplyReqDomain request){
		String content = JSON.toJSONString(request);
	    String url = test_domainurl+ "v1/acctmgr/regphone-verifycode-apply";
	    String res = RequestUtils.requestWithSign(url, content);
	    if(FuncUtils.isNull(res)){
	    	return JSON.parseObject(res, RegphoneVerifycodeApplyResDomain.class);
	    }
	    RegphoneVerifycodeApplyResDomain regphoneVerifycodeApplyResDomain = new RegphoneVerifycodeApplyResDomain();
	    regphoneVerifycodeApplyResDomain.setRet_code(SYSERROR_CODE);
	    regphoneVerifycodeApplyResDomain.setRet_msg(SYSERROR_MSG);
	    return regphoneVerifycodeApplyResDomain;
	}
	
	/**
	 * 注册手机号验证短信
	 * @param request
	 * @return
	 */
	public static RegphoneVerifycodeVerifyResDomain verifyRegphoneSms(RegphoneVerifycodeVerifyReqDomain request){
		String content = JSON.toJSONString(request);
	    String url = test_domainurl+ "v1/acctmgr/regphone-verifycode-verify";
	    String res = RequestUtils.requestWithSign(url, content);
	    if(FuncUtils.isNull(res)){
	    	return JSON.parseObject(res, RegphoneVerifycodeVerifyResDomain.class);
	    }
	    RegphoneVerifycodeVerifyResDomain regphoneVerifycodeVerifyResDomain = new RegphoneVerifycodeVerifyResDomain();
	    regphoneVerifycodeVerifyResDomain.setRet_code(SYSERROR_CODE);
	    regphoneVerifycodeVerifyResDomain.setRet_msg(SYSERROR_MSG);
	    return regphoneVerifycodeVerifyResDomain;
	}
	
	/**
	 * 个人开户申请
	 * @param request
	 * @return
	 */
	public static OpenacctApplyIndividualResDomain individualBankCardApply(OpenacctApplyIndividualReqDomain request){
		String content = JSON.toJSONString(request);
	    String url = test_domainurl+ "v1/acctmgr/openacct-apply-individual";
	    String res = RequestUtils.requestWithSign(url, content);
	    if(FuncUtils.isNull(res)){
	    	return JSON.parseObject(res, OpenacctApplyIndividualResDomain.class);
	    }
	    OpenacctApplyIndividualResDomain openacctApplyIndividualResDomain = new OpenacctApplyIndividualResDomain();
	    openacctApplyIndividualResDomain.setRet_code(SYSERROR_CODE);
	    openacctApplyIndividualResDomain.setRet_msg(SYSERROR_MSG);
	    return openacctApplyIndividualResDomain;
	}
	
	/**
	 * 个人开户验证
	 * @param request
	 * @return
	 */
	public static OpenacctVerifyIndividualResDomain individualBankCardVerify(OpenacctVerifyIndividualReqDomain request){
		String content = JSON.toJSONString(request);
	    String url = test_domainurl+ "v1/acctmgr/openacct-verify-individual";
	    String res = RequestUtils.requestWithSign(url, content);
	    if(FuncUtils.isNull(res)){
	    	return JSON.parseObject(res, OpenacctVerifyIndividualResDomain.class);
	    }
	    OpenacctVerifyIndividualResDomain openacctVerifyIndividualResDomain = new OpenacctVerifyIndividualResDomain();
	    openacctVerifyIndividualResDomain.setRet_code(SYSERROR_CODE);
	    openacctVerifyIndividualResDomain.setRet_msg(SYSERROR_MSG);
	    return openacctVerifyIndividualResDomain;
	}
	/**
	 * 银行开户
	 */
	public static BankacctApplyIndividualResDomain openBankAccount(BankacctApplyIndividualReqDomain request){
		String content = JSON.toJSONString(request);
	    String url = test_domainurl+ "v1/acctmgr/bankacct-apply-individual";
	    String res = RequestUtils.requestWithSign(url, content);
	    if(FuncUtils.isNull(res)){
	    	return JSON.parseObject(res, BankacctApplyIndividualResDomain.class);
	    }
	    BankacctApplyIndividualResDomain bankacctApplyIndividualResDomain = new BankacctApplyIndividualResDomain();
	    bankacctApplyIndividualResDomain.setRet_code(SYSERROR_CODE);
	    bankacctApplyIndividualResDomain.setRet_msg(SYSERROR_MSG);
	    return bankacctApplyIndividualResDomain;
	}
	/**
	 * 企业开户
	 * @param request
	 * @return
	 */
	public static OpenacctApplyEnterpriseResDomain enterpriseOpen(OpenacctApplyEnterpriseReqDomain request){
		String content = JSON.toJSONString(request);
	    String url = test_domainurl+ "v1/acctmgr/openacct-apply-enterprise";
	    String res = RequestUtils.requestWithSign(url, content);
	    if(FuncUtils.isNull(res)){
	    	return JSON.parseObject(res, OpenacctApplyEnterpriseResDomain.class);
	    }
	    OpenacctApplyEnterpriseResDomain openacctApplyEnterpriseResDomain = new OpenacctApplyEnterpriseResDomain();
	    openacctApplyEnterpriseResDomain.setRet_code(SYSERROR_CODE);
	    openacctApplyEnterpriseResDomain.setRet_msg(SYSERROR_MSG);
	    return openacctApplyEnterpriseResDomain;
	}
	
	/**
	 * 上传照片
	 * @param request
	 * @return
	 * @throws Exception
	 */
	public static UploadPhotosResDomain uploadPhotos(UploadPhotosReqDomain request) throws Exception{
		String content = JSON.toJSONString(request);
	    String url = test_domainurl+ "v1/acctmgr/upload-photos";
	    String res = RequestUtils.requestWithSign(url, content);
	    if(FuncUtils.isNull(res)){
	    	return JSON.parseObject(res, UploadPhotosResDomain.class);
	    }
	    UploadPhotosResDomain uploadPhotosResDomain = new UploadPhotosResDomain();
	    uploadPhotosResDomain.setRet_code(SYSERROR_CODE);
	    uploadPhotosResDomain.setRet_msg(SYSERROR_MSG);
	    return uploadPhotosResDomain;
	}
}
