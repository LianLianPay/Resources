/**
 * Copyright © 2004-2018 LianlianPay.All Rights Reserved.
 */
package com.accp.demo.openaccount.domain;

import com.accp.demo.openaccount.domain.AbstractAPIReqDomain;

public class BankacctApplyIndividualReqDomain extends AbstractAPIReqDomain{

	/** */
	private static final long serialVersionUID = 3148789858003960237L;
	
	/**
	 * 商户用户唯一编号
	 */
	private String user_id;
	/**交易流水号*/
	private String txn_seqno;
	/**交易时间*/
	private String txn_time;
//	/**异步通知地址*/
//	private String notify_url;
	public String getUser_id() {
		return user_id;
	}
	public void setUser_id(String user_id) {
		this.user_id = user_id;
	}
	public String getTxn_seqno() {
		return txn_seqno;
	}
	public void setTxn_seqno(String txn_seqno) {
		this.txn_seqno = txn_seqno;
	}
	public String getTxn_time() {
		return txn_time;
	}
	public void setTxn_time(String txn_time) {
		this.txn_time = txn_time;
	}
	
}
