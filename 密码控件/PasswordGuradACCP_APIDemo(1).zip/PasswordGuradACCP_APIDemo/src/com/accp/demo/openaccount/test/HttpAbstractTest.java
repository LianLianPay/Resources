package com.accp.demo.openaccount.test;

public abstract class HttpAbstractTest {

}
