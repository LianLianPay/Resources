package com.accp.demo.http.util;

import java.io.BufferedReader;
import java.io.InputStreamReader;

import org.apache.http.Header;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.accp.demo.util.SignatureUtil;

public class RequestUtils {

	protected  static Logger logger = LoggerFactory.getLogger(RequestUtils.class);
	
	/**
	 * 商户号
	 */
	public final static String OID_PARTNER = "2018062100009027";
	/**
	 * 商户私钥
	 */
	public final static String TRADER_PRI_KEY = "MIICdgIBADANBgkqhkiG9w0BAQEFAASCAmAwggJcAgEAAoGBAPD+malK2W3UJXfX5rO79gRUbLe+kwCskw7VzETXA4Qf/5VWlPxOb16SlflkE4zyInhGwehjUTvXPvebNtZJJpKS+Q/7oWw6hMQ1cIC99DWmV6Orjtz61Tmi5A/4QnYqUm2GRScfrnyILQw9/qikkvyjo0pPsIMT2rhmu31LSySNAgMBAAECgYEAokaubeKq2lu6ByLohCqTFINM2cWH8zJBrAGnFMu74GIzlfnBRMwEDiiiuFX9HDGHqHns5HDMKIFeMxjfKhgD0exp3S06xpSbmkIbvWLM+xBl70/+SLG7wztZ4KtdKu7PR26xJht6zM/KDrovuRzFYNB6ZbyO3My9CJXaZS6GU/kCQQD+/wsf0M7Byp+sPzy3SEn8katFopVOz8oESBBuSNNXl1rgyWfgVXBUKRDAus8oa/Nhx2zWNqpuchrHerPp5McHAkEA8fFyidW4nMkL3x4ULQmbsZBqsNEXoKv3fDDvHWRljX0AElel+XaVuxrtpYiDxwqFSM0s92nCBj2ZXt4O+d2eywJAS5mFzMr1YZMXP9QHxjcSaGUvqBeJuLH2LMrIxEmnDuL6uIY928643NrH8rvvywYmRCkB5YiTgucldVq1mHSRZQJAYny8+WrsqbYVhQ/DesnsfQ2iwLN9AMTAC+gHjlluFXiK7OyM/c3OCcpebwHxUrbvpsEOyvBcMRomMr4GLqSOnQJAcDKoXpkYFGakejn6LQj57EBtMgfVNatTipBnQxPaHMGGO9V9SzedbkgNg0NBSzsNsauKnFOy+yFwFqf6oGHm0A==";
	
	/**
	 * H5一级域名 需申请
	 */
	public final static String H5_PKG_NAME = "test";
	
	/**
	 * H5一级域名
	 */
	public final static String H5_APP_NAME = "test";
	
//	public static String TRADER_PRI_KEY = "MIICdwIBADANBgkqhkiG9w0BAQEFAASCAmEwggJdAgEAAoGBAOilN4tR7HpNYvSBra/DzebemoAiGtGeaxa+qebx/O2YAdUFPI+xTKTX2ETyqSzGfbxXpmSax7tXOdoa3uyaFnhKRGRvLdq1kTSTu7q5s6gTryxVH2m62Py8Pw0sKcuuV0CxtxkrxUzGQN+QSxf+TyNAv5rYi/ayvsDgWdB3cRqbAgMBAAECgYEAj02d/jqTcO6UQspSY484GLsL7luTq4Vqr5L4cyKiSvQ0RLQ6DsUG0g+Gz0muPb9ymf5fp17UIyjioN+ma5WquncHGm6ElIuRv2jYbGOnl9q2cMyNsAZCiSWfR++op+6UZbzpoNDiYzeKbNUz6L1fJjzCt52w/RbkDncJd2mVDRkCQQD/Uz3QnrWfCeWmBbsAZVoM57n01k7hyLWmDMYoKh8vnzKjrWScDkaQ6qGTbPVL3x0EBoxgb/smnT6/A5XyB9bvAkEA6UKhP1KLi/ImaLFUgLvEvmbUrpzY2I1+jgdsoj9Bm4a8K+KROsnNAIvRsKNgJPWd64uuQntUFPKkcyfBV1MXFQJBAJGs3Mf6xYVIEE75VgiTyx0x2VdoLvmDmqBzCVxBLCnvmuToOU8QlhJ4zFdhA1OWqOdzFQSw34rYjMRPN24wKuECQEqpYhVzpWkA9BxUjli6QUo0feT6HUqLV7O8WqBAIQ7X/IkLdzLa/vwqxM6GLLMHzylixz9OXGZsGAkn83GxDdUCQA9+pQOitY0WranUHeZFKWAHZszSjtbe6wDAdiKdXCfig0/rOdxAODCbQrQs7PYy1ed8DuVQlHPwRGtokVGHATU=";
    public static final String YT_RSA_PUBLIC = "MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCSS/DiwdCf/aZsxxcacDnooGph3d2JOj5GXWi+q3gznZauZjkNP8SKl3J2liP0O6rU/Y/29+IUe+GTMhMOFJuZm1htAtKiu5ekW0GlBMWxf4FPkYlQkPE0FtaoMP3gYfh+OwI+fIRrpW3ySn3mScnc6Z700nU/VYrRkfcSCbSnRwIDAQAB";

	protected static final String SIGNATURE_TYPE="Signature-Type";
	protected static final String SIGNATURE_DATA="Signature-Data";
    /**
     * 发起交易请求
     *
     * @return
     */
    public static String requestWithSign( String url,String jsonStr) {
        HttpClient httpClient= CustomHttpClient.GetHttpClient();
        logger.info("请求报文:" + jsonStr);
        HttpPost post = new HttpPost(url);
        logger.info("请求URL [" + url + "]");
        post.setHeader("Content-Type", "application/text;charset=UTF-8");
        try {
            String signatureData = SignatureUtil.getInstance().sign(TRADER_PRI_KEY, jsonStr);
            logger.info("请求signatureData [" + signatureData + "]");
            post.addHeader(SIGNATURE_TYPE, "RSA");
            post.addHeader(SIGNATURE_DATA, signatureData);
            StringEntity formEntiry = new StringEntity(jsonStr, "UTF-8");
            // 设置请求参数
            post.setEntity(formEntiry);
            // 发起交易
            HttpResponse resp = httpClient.execute(post);
            // 响应分析
            HttpEntity entity = resp.getEntity();
            BufferedReader br = new BufferedReader(new InputStreamReader(entity.getContent(), "utf-8"));
            StringBuffer responseString = new StringBuffer();
            String result = br.readLine();
            while (result != null) {
                responseString.append(result);
                result = br.readLine();
            }
            // 直接获取返回的字符串
            String resJson = responseString.toString();
			logger.info("返回报文:" + resJson);
			System.out.println("返回报文：" + resJson);
			String resSignatureData ="";
			Header headers[] = resp.getAllHeaders();
            int i = 0;    
            while (i < headers.length) {    
            	logger.info(headers[i].getName() + ":  " + headers[i].getValue());    
            	if(SIGNATURE_DATA.equals(headers[i].getName())){
            		resSignatureData=headers[i].getValue();
            	}
               i++;    
        
            }   
			boolean checksign = SignatureUtil.getInstance().checksign(YT_RSA_PUBLIC, resJson, resSignatureData);
			logger.info("验证签名结果:" + checksign);
			return resJson;
        } catch (Exception cte) {
            System.out.print(cte);
            return "";
        }
    }
}
