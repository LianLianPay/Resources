/**
 * Copyright © 2004-2018 LianlianPay.All Rights Reserved.
 */
package com.accp.demo.enums;

public enum ChnlFlagEnum {

	PC("PC","PC端"),
	H5("H5","Wap端"),
	ANDROID("ANDROID","ANDROID端"),
	IOS("IOS","IOS端"),
	;
	
	public String code;
	public String msg;
	
	private ChnlFlagEnum(String code,String msg){
		this.code = code;
		this.msg = msg;
	}
}
