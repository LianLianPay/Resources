package com.accp.demo.util;

import java.text.SimpleDateFormat;
import java.util.Date;

/*
 * 日期工具
 */
public class DateUtil{

	public static String getCurrentDateTimeStr1()
    {
        SimpleDateFormat dataFormat = new SimpleDateFormat("yyyyMMddHHmmss");
        Date date = new Date();
        String timeString = dataFormat.format(date);
        return timeString;
    }
}