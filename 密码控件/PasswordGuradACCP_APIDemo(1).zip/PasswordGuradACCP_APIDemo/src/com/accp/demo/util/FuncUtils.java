package com.accp.demo.util;

import javax.servlet.http.HttpServletRequest;


/**
 * 工具类
 * @author wuzf
 *
 */
public class FuncUtils{

	public static String getIpAddr(HttpServletRequest request)
    {
        String ip = request.getHeader("x-forwarded-for");
        if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip))
        {
            ip = request.getHeader("Proxy-Client-IP");
        }
        if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip))
        {
            ip = request.getHeader("WL-Proxy-Client-IP");
        }
        if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip))
        {
            ip = request.getRemoteAddr();
        }
        if (!isNull(ip) && ip.contains(","))
        {
            String[] ips = ip.split(",");
            ip = ips[ips.length - 1];
        }
        ip = isNull(ip) ? ip : ip.trim();
        return ip;
    }
	
	public static boolean isNull(String str)
    {
        if (null == str || str.equalsIgnoreCase("NULL") || str.equals(""))
        {
            return true;
        } else
            return false;
    }
}
