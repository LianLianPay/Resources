package com.accp.demo.util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


/**
 * RSA签名公共类
 * 
 */
public class SignatureUtil {

	private static Logger log = LoggerFactory.getLogger(SignatureUtil.class);
	private static  final String CHARSET="UTF-8";
	private static SignatureUtil instance;
	private SignatureUtil() {

	}

	public static SignatureUtil getInstance() {
		if (null == instance)
			return new SignatureUtil();
		return instance;
	}

	/**
	 * 签名处理
	 * 
	 * @param prikeyvalue
	 *            ：私钥
	 * @param sign_str
	 *            ：签名源内容
	 * @return
	 */
	@SuppressWarnings("static-access")
	public  String sign(String prikeyvalue, String sign_str) {
		try {
			String hash = Md5Algorithm.getInstance().md5Digest(sign_str.getBytes(CHARSET));
			return RSAUtil.getInstance().sign(prikeyvalue, hash);
		} catch (java.lang.Exception e) {
			log.error("签名失败,{}" , e.getMessage());
		}
		return null;
	}

	/**
	 * 签名验证
	 * 
	 * @param pubkeyvalue
	 *            ：公钥
	 * @param sign_str
	 *            ：源串
	 * @param signed_str
	 *            ：签名结果串
	 * @return
	 */
	@SuppressWarnings("static-access")
	public  boolean checksign(String pubkeyvalue, String sign_str, String signed_str) {
		try {
			String hash = Md5Algorithm.getInstance().md5Digest(sign_str.getBytes(CHARSET));
			return RSAUtil.getInstance().checksign(pubkeyvalue, hash, signed_str);
		} catch (java.lang.Exception e) {
			log.error("签名验证异常,{}" , e.getMessage());
		}
		return false;
	}
	public static void main(String args[]){
		String rsa_public ="MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCSS/DiwdCf/aZsxxcacDnooGph3d2JOj5GXWi+q3gznZauZjkNP8SKl3J2liP0O6rU/Y/29+IUe+GTMhMOFJuZm1htAtKiu5ekW0GlBMWxf4FPkYlQkPE0FtaoMP3gYfh+OwI+fIRrpW3ySn3mScnc6Z700nU/VYrRkfcSCbSnRwIDAQAB";
		String oid_str ="{\"oid_partner\":\"2018062700013011\",\"random_key\":\"cf969288-24c8-4784-a7de-2c29a860d383\",\"random_value\":\"36022705461348244442286336628152\",\"ret_code\":\"0000\",\"ret_msg\":\"交易成功\",\"rsa_public_content\":\"MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCSS/DiwdCf/aZsxxcacDnooGph3d2JOj5GXWi+q3gznZauZjkNP8SKl3J2liP0O6rU/Y/29+IUe+GTMhMOFJuZm1htAtKiu5ekW0GlBMWxf4FPkYlQkPE0FtaoMP3gYfh+OwI+fIRrpW3ySn3mScnc6Z700nU/VYrRkfcSCbSnRwIDAQAB\",\"user_id\":\"12356\"}";
		String signed_str ="N+5t0CryvZHogOclgz8O9l45qXOFO8hQDq7eFlKIgQC8aDd+w+2XKzQkVGCWn24f/ZZRENxr125+WZKipo7z40Zgh1Vgzw7RiSMq389GzSkk0jErPdPklkmTTDzODZOdgvo4c2ED0moTUGIHhOgWLmbvLxSXcsp/TfRFj2+S+AE=";
		System.out.print(SignatureUtil.getInstance().checksign(rsa_public,oid_str,signed_str));
	}
}
