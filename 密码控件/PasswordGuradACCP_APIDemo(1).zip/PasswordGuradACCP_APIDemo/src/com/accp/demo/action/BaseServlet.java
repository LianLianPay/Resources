/**
 * Copyright © 2004-2018 LianlianPay.All Rights Reserved.
 */
package com.accp.demo.action;

import javax.servlet.http.HttpServlet;

public class BaseServlet extends HttpServlet{

	/** */
	private static final long serialVersionUID = 5555881049623451804L;

	/**
	 * 获取随机因子接口
	 */
	public final static String SERVER_URL = "https://accptest.lianlianpay-inc.com/openapi/v1/acctmgr/get-random.htm";
}
