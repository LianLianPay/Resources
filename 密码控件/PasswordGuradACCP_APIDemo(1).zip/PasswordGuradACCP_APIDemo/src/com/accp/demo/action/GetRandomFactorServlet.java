/**
 * Copyright © 2004-2018 LianlianPay.All Rights Reserved.
 */
package com.accp.demo.action;

import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.accp.demo.enums.ChnlFlagEnum;
import com.accp.demo.http.util.RequestUtils;
import com.accp.demo.openaccount.domain.GetPasswordRandomReqDomain;
import com.alibaba.fastjson.JSON;

/**
 * 
* 描述说明
* 商户服务端：获取随机因子服务端 服务接口
* @version V1.0
* @author @lianlian.com
* @Date 2018年12月13日 下午3:44:01
* @since JDK 1.6
 */
public class GetRandomFactorServlet extends BaseServlet{

	/** */
	private static final long serialVersionUID = 644737478405649391L;

	/**
	 * 商户端服务端：获取随机因子服务
	 * @see javax.servlet.http.HttpServlet#doPost(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
	 */
	@Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp){
		GetPasswordRandomReqDomain request = new GetPasswordRandomReqDomain();
		request.setFlag_chnl(req.getParameter("flag_chnl"));
		if(ChnlFlagEnum.H5.code.equals(req.getParameter("flag_chnl"))){
			request.setApp_name(RequestUtils.H5_APP_NAME);
			request.setPkg_name(RequestUtils.H5_PKG_NAME);
		}
		
		DateFormat df = new SimpleDateFormat("yyyyMMddHHmmss");
		Date date = new Date();
		request.setTimestamp(df.format(date));
		request.setUser_id("user_id");
		request.setOid_partner(RequestUtils.OID_PARTNER);
		
		/**
		 * 请求账户+服务接口
		 */
		String result = RequestUtils.requestWithSign(SERVER_URL, JSON.toJSONString(request));
		resp.setCharacterEncoding("UTF-8");
		try {
			resp.getWriter().write(result);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
