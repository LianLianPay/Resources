	function encrypt(){
		if(pgeditor1.osBrowser == 10 || pgeditor1.osBrowser == 11){
			var wid1 = pgeditor1.settings.pgeWindowID;
			var wid2 = pgeditor2.settings.pgeWindowID;
			pgeditor1.pwdLength(function(){
				if(outs[wid1].length==0){//长度校验
					alert("密码不能为空");
					return;
				}
				pgeditor1.pwdValid(function(){//正则表达式校验
					if(outs[wid1].valid==1){
						alert("密码不符合要求");
						return;
					}
					
					pgeditor2.pwdLength(function(){//长度校验
						if(outs[wid2].length==0){
							alert("确认密码不能为空");
							return;
						}
						pgeditor2.pwdValid(function(){//正则表达式校验
							if(outs[wid2].valid==1){
								alert("确认密码不符合要求");
								return;
							}
							/**
							* 请求商户服务端：获取随机因子
							*/
							var param = {flag_chnl:"PC"}
							$.ajax({
						        url : "CreateRandomFactor.htm",
						        async: false,
						        type : "POST",
						        dataType : "json",
						        data:param,
						        success:function(data){
						        	//data = eval("(" + data + ")");
						        	if(data.ret_code){
						        		if(data.ret_code == '0000'){
						        			$("#random_key").val(data.random_key);
						        			$("#random_value").val(data.random_value);
						        			
						        			pgeditor1.pwdSetSk(data.random_value,function(){//设置随机因子value
												pgeditor2.pwdSetSk(data.random_value,function(){
													pgeditor1.pwdHash(function(){
														pgeditor2.pwdHash(function(){
															if(outs[wid1].hash!=outs[wid2].hash){//hash判断密码是否相等
																alert("密码不一致");
																return;
															}
															pgeditor1.pwdResultRsa(function(){
																//获取密文
																$("#password_ciphertext").val(outs[wid1].aes);
																
																//TODO 商户提交带有密文接口
																print();
															});
														});
													});
												});
											});
						        		}else{
						        			alert("获取随机因子失败");
						        			return false;
						        		}
						        	}else{
						        		alert("获取随机因子失败");
						        		return false;
						        	}
						        }
						    });
							
						});
					});
				});
			});
		}else{
			if (pgeditor1.pwdLength() == 0) {//长度校验
				alert("密码不能为空");
				return false;
			}
			if (pgeditor1.pwdValid() == 1) {//正则表达式校验
				alert("密码不符合要求");
				return false;
			}
			if (pgeditor2.pwdLength() == 0) {//长度校验
				alert("确认密码不能为空");
				return false;
			}
			if (pgeditor2.pwdValid() == 1) {//正则表达式校验
				alert("确认密码不符合要求");
				return false;
			}
			/***
			* 请求商户服务端 ： 获取随机因子
			*/
			var param = {flag_chnl:"PC"}
			$.ajax({
		        url : "CreateRandomFactor.htm",
		        async: false,
		        type : "POST",
		        dataType : "json",
		        data:param,
		        success:function(data){
		        	//data = eval("(" + data + ")");
		        	if(data.ret_code){
		        		if(data.ret_code == '0000'){
		        			$("#random_key").val(data.random_key);
		        			$("#random_value").val(data.random_value);
		        			//设置随机因子value
		    				pgeditor1.pwdSetSk(data.random_value);
		        		}else{
		        			alert("获取随机因子失败");
		        			return false;
		        		}
		        	}else{
		        		alert("获取随机因子失败");
		        		return false;
		        	}
		        }
		    });
			
			if(pgeditor1.pwdHash()!=pgeditor2.pwdHash()){//hash判断密码是否相等
				alert("密码不一致");
			return false;
			}
			//获取密文
			$("#password_ciphertext").val(pgeditor1.pwdResultRsa());
			//TODO 商户提交带有密文接口
			
			print();
		}
	}
	
	function print(){
		var d = {};
	    var t = $('#form').serializeArray();
	    $.each(t, function() {
	      d[this.name] = this.value;
	    });
	    console.log("提交信息:" + JSON.stringify(d));
	    alert(JSON.stringify(d));
	}