# U-Key

本仓库提供有U-Key（即天威盾）安装过程中所需的驱动和证书安装助手的安装文件。

商户可根据[开放平台-商户站实时付款-天威盾安装说明](https://open.lianlianpay.com/docs/send-money/instant/ukey.html#%E5%AE%89%E8%A3%85u-key%E9%A9%B1%E5%8A%A8%E4%B8%8Eu-key%E5%AE%89%E5%85%A8%E8%AF%81%E4%B9%A6%E5%8A%A9%E6%89%8B)进行安装。

如有疑问可咨询[连连技术支持部](mailto:tech_support@lianlianpay.com)。